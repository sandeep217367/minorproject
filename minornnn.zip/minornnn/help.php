<?php require 'config/db.php'; ?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Help</title>
  <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<?php include __DIR__ . '/inc/header.php'; ?>
<main class="dashboard-wrap">
  <h2>Help & Documentation</h2>
  <p class="muted">This page contains basic help and FAQs for using the Transparency Tracker. Expand as needed.</p>
  <div class="form">
    <h3>Frequently Asked Questions</h3>
    <ul>
      <li>How do I file a complaint? <a href="file_complaint.php">File Complaint</a></li>
      <li>How do I track the status? <a href="track.php">Track Complaint</a></li>
      <li>Need more help? Contact support at <a href="mailto:support@example.com">support@example.com</a></li>
    </ul>
  </div>
</main>
<?php include __DIR__ . '/inc/footer.php'; ?>
</body>
</html>
