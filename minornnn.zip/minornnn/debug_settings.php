<?php
require 'config/db.php';

try {
    $stmt = $pdo->query('SELECT * FROM system_settings');
    $settings = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo '<h1>System Settings</h1>';
    echo '<table border="1" cellpadding="5" cellspacing="0">';
    echo '<tr><th>Setting Key</th><th>Setting Value</th><th>Description</th><th>Updated At</th></tr>';

    foreach ($settings as $setting) {
        echo '<tr>';
        echo '<td>' . htmlspecialchars($setting['setting_key']) . '</td>';
        echo '<td>' . htmlspecialchars($setting['setting_value']) . '</td>';
        echo '<td>' . htmlspecialchars($setting['setting_description']) . '</td>';
        echo '<td>' . htmlspecialchars($setting['updated_at']) . '</td>';
        echo '</tr>';
    }

    echo '</table>';
} catch (Exception $e) {
    echo '<p>Error: ' . htmlspecialchars($e->getMessage()) . '</p>';
}
?>