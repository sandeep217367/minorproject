<?php require 'config/db.php'; ?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Feedback</title>
  <link rel="stylesheet" href="assets/style.css">
  <script src="assets/app.js" defer></script>
</head>
<body>
<?php include __DIR__ . '/inc/header.php'; ?>
<main class="dashboard-wrap">
  <h2>Submit Feedback</h2>
  <div class="form">
    <form id="feedbackForm">
      <label>Complaint ID</label>
      <input name="complaint_id" type="text" pattern="^(?:CTRT-)?[0-9]+$" placeholder="Enter CTRT-123 or just 123">
      <label>Rating (1-5)</label>
      <select name="rating"><option>5</option><option>4</option><option>3</option><option>2</option><option>1</option></select>
      <label>Comments</label>
      <textarea name="comments" rows="4"></textarea>
      <div style="margin-top:.6rem"><button class="btn" type="button" id="sendFeedback">Send Feedback</button></div>
    </form>
    <div id="fbMsg" class="muted" style="margin-top:.6rem"></div>
  </div>
</main>
<?php include __DIR__ . '/inc/footer.php'; ?>
<script>
document.getElementById('sendFeedback').addEventListener('click', async ()=>{
  const btn = document.getElementById('sendFeedback');
  const f = document.getElementById('feedbackForm');
  const msg = document.getElementById('fbMsg');
  btn.disabled = true; btn.classList.add('disabled');
  msg.textContent = 'Sending...';
  try{
    const complaintIdInput = document.querySelector('input[name="complaint_id"]');
    const complaintId = complaintIdInput.value.trim();
    
    if (!complaintId) {
      msg.textContent = 'Please enter a complaint ID';
      btn.disabled = false;
      btn.classList.remove('disabled');
      return;
    }

    // Add CTRT- prefix if not present
    complaintIdInput.value = complaintId.startsWith('CTRT-') ? complaintId : 'CTRT-' + complaintId;
    
    if (!complaintIdInput.value.match(/^CTRT-\d+$/)) {
      msg.textContent = 'Please enter a valid complaint ID (CTRT-123 or just 123)';
      btn.disabled = false;
      btn.classList.remove('disabled');
      return;
    }
    
    const data = new FormData(f);
    const res = await fetch('feedback_submit.php',{method:'POST',body:data});
    const j = await res.json();
    if(j.ok){
      msg.textContent = 'Thanks for your feedback.';
      // reload shortly so user sees the message then refreshed state
      setTimeout(()=> location.reload(), 900);
    } else {
      msg.textContent = j.msg || 'Error submitting feedback.';
      btn.disabled = false; btn.classList.remove('disabled');
    }
  }catch(e){
    console.error(e);
    msg.textContent = 'Network error.';
    btn.disabled = false; btn.classList.remove('disabled');
  }
});
</script>
</body>
</html>
