<?php
require 'config/db.php';

try {
    $stmt = $pdo->prepare('UPDATE system_settings SET setting_value = ? WHERE setting_key = ?');
    $stmt->execute(['New Site Name', 'site_name']);
    echo 'Update successful';
} catch (Exception $e) {
    echo 'Error: ' . $e->getMessage();
}