<?php
require_once 'config/db.php';

try {
    $stmt = $pdo->prepare("SELECT * FROM admins WHERE email = 'testadmin@example.com'");
    $stmt->execute();
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($admin && $admin['password'] === 'testpassword') {
        echo "Admin login successful.";
    } else {
        echo "Admin login failed.";
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
