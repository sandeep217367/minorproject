<?php
require __DIR__ . '/config/db.php';
$admin = $pdo->query("SELECT admin_id,email,password FROM admins WHERE admin_id = 4 LIMIT 1")->fetch();
if(!$admin){ echo "Admin not found\n"; exit; }
$ok = password_verify('testpassword', $admin['password']);
echo "Admin id {$admin['admin_id']} ({$admin['email']}) password_verify('testpassword') => ";
echo $ok ? "TRUE\n" : "FALSE\n";
?>