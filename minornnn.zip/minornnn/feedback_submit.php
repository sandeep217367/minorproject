<?php
require 'config/db.php';
session_start();
header('Content-Type: application/json');

if($_SERVER['REQUEST_METHOD']!=='POST'){ 
    echo json_encode(['ok'=>false,'msg'=>'POST required']); 
    exit; 
}

// Get and clean input
$complaintId = trim($_POST['complaint_id'] ?? '');
$rating = (int)($_POST['rating'] ?? 0);
$comments = trim($_POST['comments'] ?? '');
$userId = $_SESSION['user_id'] ?? null;

// Extract numeric ID from CTRT-format if provided
if (preg_match('/^CTRT-?(\d+)$/', $complaintId, $matches)) {
    $cid = (int)$matches[1];
} else {
    $cid = (int)$complaintId;
}

// First validate required inputs
if(!$cid) {
    echo json_encode(['ok' => false, 'msg' => 'Please enter a complaint ID']);
    exit;
}

if(!$rating || $rating < 1 || $rating > 5) {
    echo json_encode(['ok' => false, 'msg' => 'Please provide a valid rating (1-5)']);
    exit;
}

// Validate complaint exists and belongs to the user (if logged in)
try {
    $sql = 'SELECT c.complaint_id, c.user_id FROM complaints c WHERE c.complaint_id = ?';
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$cid]);
    $complaint = $stmt->fetch();

    if (!$complaint) {
        echo json_encode(['ok' => false, 'msg' => 'Complaint ID CTRT-' . str_pad($cid, 6, '0', STR_PAD_LEFT) . ' not found']);
        exit;
    }

    // If user is logged in, verify they own the complaint
    if ($userId && $complaint['user_id'] != $userId) {
        echo json_encode(['ok' => false, 'msg' => 'You can only provide feedback for your own complaints']);
        exit;
    }

    // Check if feedback already exists for this complaint
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM feedback WHERE complaint_id = ?');
    $stmt->execute([$cid]);
    if ($stmt->fetchColumn() > 0) {
        echo json_encode(['ok' => false, 'msg' => 'Feedback already submitted for this complaint']);
        exit;
    }

    // All validation passed, insert feedback
    $stmt = $pdo->prepare('INSERT INTO feedback (complaint_id, user_id, rating, comments) VALUES (?, ?, ?, ?)');
    $stmt->execute([$cid, $userId, $rating, $comments]);
    echo json_encode(['ok' => true, 'msg' => 'Thank you for your feedback']);

} catch (Exception $e) {
    echo json_encode(['ok' => false, 'msg' => 'Database error: ' . $e->getMessage()]);
    exit;
}

?>
