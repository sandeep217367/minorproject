<?php
require 'config/db.php';
session_start();
$email = trim($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';
if(!$email || !$password){ header('Location: officer_login.php'); exit; }

// Ensure officers table exists (schema migration safe)
$pdo->exec("CREATE TABLE IF NOT EXISTS officers (
  officer_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(191) NOT NULL,
  department VARCHAR(191) DEFAULT NULL,
  email VARCHAR(191) DEFAULT NULL,
  phone VARCHAR(50) DEFAULT NULL,
  password_hash VARCHAR(255) DEFAULT NULL
)");

// If table exists but column missing, try to add it (best-effort)
try{
  $pdo->query("SELECT password_hash FROM officers LIMIT 1");
}catch(PDOException $e){
  // try to add column
  try{ $pdo->exec("ALTER TABLE officers ADD COLUMN password_hash VARCHAR(255) DEFAULT NULL"); } catch(Exception $ex){}
}

$stmt = $pdo->prepare('SELECT officer_id,name,password_hash FROM officers WHERE email = ? LIMIT 1');
$stmt->execute([$email]);
$row = $stmt->fetch();
if($row && !empty($row['password_hash']) && password_verify($password, $row['password_hash'])){
  // login
  $_SESSION['officer_id'] = $row['officer_id'];
  $_SESSION['officer_name'] = $row['name'];
  header('Location: officer_dashboard.php'); exit;
}
// invalid
header('Location: officer_login.php?error=1'); exit;
