<?php
// Simple site header / nav used across public pages
// Start session if not started so we can detect admin login
if(session_status() === PHP_SESSION_NONE){ @session_start(); }
$isAdmin = !empty($_SESSION['admin_id']);
$isOfficer = !empty($_SESSION['officer_id']);
$isUser = !empty($_SESSION['user_id']) && empty($_SESSION['admin_id']) && empty($_SESSION['officer_id']);
?>
<header>
  <nav class="nav">
    <div style="display:flex;align-items:center;gap:1rem">
      <button id="navToggle" aria-label="Toggle navigation" class="nav-toggle">☰</button>
      <div class="brand">
        <img src="assets/images/logo.svg" alt="logo" style="height:28px;vertical-align:middle;margin-right:.5rem">CTRT Transparency Tracker
      </div>
    </div>
    <?php if($isAdmin): ?>
      <ul class="nav-links" id="mainNav">
        <li><a href="admin_dashboard.php">Dashboard</a></li>
        <li><a href="admin_actions.php">Manage</a></li>
        <li><a href="users.php">Users</a></li>
        <li><a href="officers.php">Officers</a></li>
        <li><a href="export_csv.php">Reports</a></li>
        <li><a href="admin_feedback.php">Feedback</a></li>
        <li><a href="admin_logout.php">Logout</a></li>
      </ul>
    <?php elseif($isOfficer): ?>
      <ul class="nav-links" id="mainNav">
        <li><a href="officer_dashboard.php">Officer Dashboard</a></li>
        <li><a href="officer_logout.php">Logout</a></li>
      </ul>
    <?php elseif($isUser): ?>
      <ul class="nav-links" id="mainNav">
        <li><a href="user_dashboard.php">Dashboard</a></li>
        <li><a href="file_complaint.php">File Complaint</a></li>
        <li><a href="track.php">Track Complaint</a></li>
        <li><a href="help.php">Help</a></li>
        <li><a href="feedback_form.php">Feedback</a></li>
        <li><a href="logout.php">Logout</a></li>
      </ul>
    <?php else: ?>
      <ul class="nav-links" id="mainNav">
        <li><a href="index.php">Home</a></li>
        <li><a href="file_complaint.php">File Complaint</a></li>
        <li><a href="track.php">Track Complaint</a></li>
        <li><a href="feedback_form.php">Feedback</a></li>
        <li><a href="help.php">Help</a></li>
        <li><a href="register.php">Register</a></li>
        <li><a href="login.php">Login</a></li>
      </ul>
    <?php endif; ?>
  </nav>
</header>
