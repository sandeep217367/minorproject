<?php
// Centralized footer used across public, admin and officer pages.
// Keeps a small HTML footer and loads the site JS once.
?>
<footer>
	<div style="max-width:900px;margin:0 auto;padding:1rem;display:flex;justify-content:space-between;align-items:center;">
		<div class="muted">&copy; <?=date('Y')?> Complaint Tracker — All rights reserved.</div>
		<div class="muted">Contact: <a href="mailto:support@example.com">support@example.com</a></div>
	</div>
</footer>
<script src="assets/app.js" defer></script>
