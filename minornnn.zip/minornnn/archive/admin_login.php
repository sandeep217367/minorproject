<?php
// Backup copy of admin_login.php moved to archive on user request
// Original contents preserved for rollback
require 'config/db.php';
session_start();
$errors=[];
if($_SERVER['REQUEST_METHOD']==='POST'){
  $login = $_POST['email']??''; $pw = $_POST['password']??'';
  $a = null;
  try{
    // Check if admins table exists
    $hasAdmins = (bool)$pdo->query("SHOW TABLES LIKE 'admins'")->fetchColumn();
    if($hasAdmins){
      $stmt = $pdo->prepare('SELECT * FROM admins WHERE email=?');
      $stmt->execute([$login]);
      $a = $stmt->fetch();
    }
    // Fallback to legacy admin table if no row found or admins table missing
    if(!$a){
      $hasLegacy = (bool)$pdo->query("SHOW TABLES LIKE 'admin'")->fetchColumn();
      if($hasLegacy){
        $stmt = $pdo->prepare('SELECT * FROM admin WHERE username=?');
        $stmt->execute([$login]);
        $a = $stmt->fetch();
        if($a){ // normalize fields for session
          $a['admin_id'] = $a['admin_id'] ?? $a['admin_id'];
          $a['name'] = $a['username'];
          $a['email'] = $a['username'] . '@example.com';
        }
      }
    }
  } catch (Exception $e){
    $errors[] = 'Database error: '.esc($e->getMessage());
  }

  if($a && password_verify($pw, $a['password'])){
    $_SESSION['admin_id']=$a['admin_id']; $_SESSION['admin_name']=$a['name']; header('Location: admin_dashboard.php'); exit;
  }
  $errors[]='Invalid admin credentials';
}
?>
<!doctype html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Admin Login</title><link rel="stylesheet" href="assets/style.css"></head>
<body>
<?php include __DIR__ . '/inc/header.php'; ?>
<main class="dashboard-wrap" style="text-align:left; background-image:url('assets/images/hero-bg.svg'); background-size:cover; background-position:center;">
  <div class="form" style="max-width:580px;margin:1rem auto">
    <h2>Admin Login</h2>
    <?php foreach($errors as $e) echo '<p style="color:red">'.esc($e).'</p>'; ?>
    <form method="post">
      <label>Email</label><input name="email" type="email" required>
      <label>Password</label><input name="password" type="password" required>
      <div style="margin-top:.6rem"><button class="btn" type="submit">Login</button></div>
      <div style="display:flex;justify-content:space-between;margin-top:1rem">
        <a class="muted" href="login.php">User Login</a>
        <a class="muted" href="admin_register.php">Admin Register</a>
      </div>
    </form>
  </div>
</main>
<?php include __DIR__ . '/inc/footer.php'; ?>
</body></html>
