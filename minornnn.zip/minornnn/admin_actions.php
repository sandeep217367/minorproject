<?php
require 'config/db.php';
session_start();
if(empty($_SESSION['admin_id'])){ header('Location: admin_login.php'); exit; }
if($_SERVER['REQUEST_METHOD']==='POST'){
  $id = (int)($_POST['id']??0);
  $status = $_POST['status']??null;
  $assigned = $_POST['assigned_to']? (int)$_POST['assigned_to'] : null;
  $note = $_POST['resolution_note']??null;
  $fields=[]; $params=[];
  // detect columns to avoid SQL errors on different schemas
  $hasAssigned = (bool)$pdo->query("SHOW COLUMNS FROM complaints LIKE 'assigned_to'")->fetchColumn();
  $hasRemarks = (bool)$pdo->query("SHOW COLUMNS FROM complaints LIKE 'remarks'")->fetchColumn();
  $hasUpdated = (bool)$pdo->query("SHOW COLUMNS FROM complaints LIKE 'updated_at'")->fetchColumn();
  if($status){ $fields[]='status=?'; $params[]=$status; }
  if($assigned && $hasAssigned){ $fields[]='assigned_to=?'; $params[]=$assigned; }
  if($note && $hasRemarks){ $fields[]='remarks=?'; $params[]=$note; if(strtolower($status)=='resolved' && $hasUpdated) $fields[]='updated_at=NOW()'; }
  if($fields){
    $params[]=$id;
    $sql = 'UPDATE complaints SET '.implode(',', $fields).' WHERE complaint_id=?';
    $pdo->prepare($sql)->execute($params);
  }
}
header('Location: admin_dashboard.php'); exit;
