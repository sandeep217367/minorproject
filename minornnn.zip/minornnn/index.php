<?php
require 'config/db.php';

// Defensive DB access: wrap queries in try/catch so a missing column/table doesn't trigger a fatal error.
$db_error = '';
$resolved = [];
$ratings = [];
try {
  // Fetch recent resolved complaints for transparency wall / carousel
  // Use existing schema: category, remarks, updated_at
  $stmt = $pdo->prepare("SELECT c.complaint_id, c.category, c.description, c.remarks, c.updated_at, u.name AS user_name
               FROM complaints c
               JOIN users u ON c.user_id=u.user_id
               WHERE LOWER(c.status)='resolved' OR c.status='Resolved' ORDER BY c.updated_at DESC LIMIT 6");
  $stmt->execute();
  $resolved = $stmt->fetchAll();

  // Calculate average rating per category (if feedback table exists)
  $hasFeedback = $pdo->query("SHOW TABLES LIKE 'feedback'")->fetchColumn();
  if($hasFeedback){
    $stmt = $pdo->prepare("SELECT c.category, AVG(f.rating) AS avg_rating FROM feedback f JOIN complaints c ON f.complaint_id=c.complaint_id GROUP BY c.category");
    $stmt->execute();
    foreach($stmt->fetchAll() as $r){ $ratings[$r['category']] = round($r['avg_rating'],2); }
  }
} catch (Exception $e) {
  // Store error for display in the UI and allow the page to render partially.
  $db_error = $e->getMessage();
}

// Provide small AJAX endpoints for the homepage to refresh sections without reload
if(isset($_GET['ajax'])){
  $t = $_GET['ajax'];
  header('Content-Type: application/json');
  if($t === 'ratings'){
    echo json_encode(['ok'=>true,'ratings'=>$ratings]);
    exit;
  }
  if($t === 'resolved'){
    echo json_encode(['ok'=>true,'resolved'=>$resolved]);
    exit;
  }
  echo json_encode(['ok'=>false,'msg'=>'unknown']); exit;
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Complaint-to-Resolution Transparency Tracker</title>
  <link rel="stylesheet" href="assets/style.css">
  <script src="assets/app.js" defer></script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
  <?php include __DIR__ . '/inc/header.php'; ?>

  <?php if(!empty($db_error)): ?>
    <div style="background:#fee2e2;color:#991b1b;padding:1rem;margin:1rem;border-radius:8px;max-width:900px;margin-left:auto;margin-right:auto;">
      <strong>Database error:</strong>
      <div style="font-family:monospace;white-space:pre-wrap;"><?=esc($db_error)?></div>
      <p>Run <a href="db_status.php">db_status.php</a> to list tables/columns and verify your schema.</p>
    </div>
  <?php endif; ?>

  <header class="hero">
    <div>
      <h1>Complaint-to-Resolution Transparency Tracker</h1>
      <p>Track complaints end-to-end  from filing to resolution. Built for transparency and accountability.</p>
      <div style="margin-top:1rem;display:flex;gap:.6rem;align-items:center">
        <a class="btn" href="file_complaint.php">File a Complaint</a>
        <a class="btn" href="track.php" style="background:#fff;color:var(--accent);border:1px solid #e6eefc">Track</a>
        <button class="btn" id="quickFileBtn" style="background:#10b981">Quick file</button>
      </div>

      <div class="features">
        <div class="feature-card"><img src="assets/images/icon-analytics.svg" alt="public" style="width:48px;height:48px"><h4>Public Tracking</h4><p class="muted">Share and monitor complaint status publicly for transparency.</p></div>
        <div class="feature-card"><img src="assets/images/icon-analytics.svg" alt="analytics" style="width:48px;height:48px"><h4>Analytics</h4><p class="muted">Visualise resolution times and department performance.</p></div>
        <div class="feature-card"><img src="assets/images/icon-analytics.svg" alt="support" style="width:48px;height:48px"><h4>Support</h4><p class="muted">Get assistance and updates from assigned officers.</p></div>
      </div>
    </div>
    <!-- hero illustration background is applied via CSS -->
  </header>

  <section class="ratings">
    <h2>Average Ratings by Department <button id="refreshRatings" class="btn" style="background:#fff;color:var(--accent);border:1px solid #e6eefc;margin-left:1rem">Refresh</button></h2>
    <div class="rating-list">
      <?php foreach($ratings as $dept => $avg): ?>
        <div class="rating-item"><strong><?=esc($dept)?></strong><span><?=esc($avg)?> ★</span></div>
      <?php endforeach; ?>
      <?php if(empty($ratings)) echo '<p>No ratings yet.</p>'; ?>
    </div>
  </section>

  <section class="resolved">
    <h2>Transparency Wall — Recent Resolved Complaints <button id="refreshResolved" class="btn" style="background:#fff;color:var(--accent);border:1px solid #e6eefc;margin-left:1rem">Refresh</button></h2>
    <div class="carousel">
      <?php foreach($resolved as $r): ?>
        <article class="card">
          <h3><?=esc($r['category']?:'Untitled')?></h3>
          <p><strong>Category:</strong> <?=esc($r['category'])?></p>
          <p><?=nl2br(esc($r['remarks']?:'Summary not provided'))?></p>
          <p class="muted">Resolved on <?=esc($r['updated_at'])?> by <?=esc($r['user_name'])?></p>
        </article>
      <?php endforeach; ?>
      <?php if(empty($resolved)) echo '<p>No resolved complaints yet.</p>'; ?>
    </div>
  </section>

  <div id="quickFileModal" class="modal-backdrop hidden">
    <div class="modal">
      <h3>Quick File a Complaint</h3>
      <p class="muted">Fill minimal fields to quickly register an issue; you can add details later.</p>
      <div class="form-row"><label>Category</label><select id="quickCat"><option>Sanitation</option><option>Transport</option><option>Other</option></select></div>
      <div class="form-row"><label>Description</label><textarea id="quickDesc" rows="3"></textarea></div>
      <div class="btn-row"><button class="btn" id="quickFileClose">Close</button><button class="btn" id="quickFileSubmit" style="background:#10b981">Submit</button></div>
    </div>
  </div>

  <footer>
    <div class="footer-grid" style="max-width:1100px;margin:0 auto;padding:1rem">
      <div>
        <strong>Transparency Tracker</strong>
        <p class="muted">Track complaints from filing through to resolution, publicly and transparently.</p>
      </div>
      <div>
        <h4>Quick Links</h4>
        <p><a href="file_complaint.php">File Complaint</a> • <a href="track.php">Track</a></p>
        <p><a href="register.php">Register</a> • <a href="login.php">Login</a></p>
      </div>
      <div style="text-align:right">
        <h4>Contact</h4>
        <p class="muted">support@example.com</p>
      </div>
    </div>
  </footer>
</body>
</html>
