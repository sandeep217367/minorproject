<?php
require_once 'config/db.php';

try {
    $stmt = $pdo->query('SELECT officer_id FROM officers');
    $officers = $stmt->fetchAll(PDO::FETCH_COLUMN);
    echo "Existing officer IDs:\n";
    foreach ($officers as $id) {
        echo $id . "\n";
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
