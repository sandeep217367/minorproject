<?php
require 'config/db.php';
session_start();
if(empty($_SESSION['admin_id'])){ header('Location: admin_login.php'); exit; }

// Ensure officers table exists
$pdo->exec("CREATE TABLE IF NOT EXISTS officers (
  officer_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(191) NOT NULL,
  department VARCHAR(191) DEFAULT NULL,
  email VARCHAR(191) DEFAULT NULL,
  phone VARCHAR(50) DEFAULT NULL,
  password_hash VARCHAR(255) DEFAULT NULL
)");

$action = $_POST['action'] ?? '';
if($action === 'create'){
  $name = trim($_POST['name'] ?? '');
  $dept = trim($_POST['department'] ?? '');
  $email = trim($_POST['email'] ?? '');
  $phone = trim($_POST['phone'] ?? '');
  $password = $_POST['password'] ?? '';
  if($name){
    if($password){
      $hash = password_hash($password, PASSWORD_DEFAULT);
      $stmt = $pdo->prepare('INSERT INTO officers (name,department,email,phone,password_hash) VALUES (?,?,?,?,?)');
      $stmt->execute([$name,$dept,$email,$phone,$hash]);
    } else {
      $stmt = $pdo->prepare('INSERT INTO officers (name,department,email,phone) VALUES (?,?,?,?)');
      $stmt->execute([$name,$dept,$email,$phone]);
    }
  }
  header('Location: officers.php'); exit;
}
if($action === 'update'){
  $id = (int)($_POST['officer_id']??0);
  $name = trim($_POST['name'] ?? '');
  $dept = trim($_POST['department'] ?? '');
  $email = trim($_POST['email'] ?? '');
  $phone = trim($_POST['phone'] ?? '');
  $password = $_POST['password'] ?? '';

  // Validate inputs
  if(!$id || !$name || !filter_var($email, FILTER_VALIDATE_EMAIL)){
    header('Location: officers.php?error=Invalid input'); exit;
  }

  try {
    if($password){
      $hash = password_hash($password, PASSWORD_DEFAULT);
      $stmt = $pdo->prepare('UPDATE officers SET name=?,department=?,email=?,phone=?,password_hash=? WHERE officer_id=?');
      $stmt->execute([$name,$dept,$email,$phone,$hash,$id]);
    } else {
      $stmt = $pdo->prepare('UPDATE officers SET name=?,department=?,email=?,phone=? WHERE officer_id=?');
      $stmt->execute([$name,$dept,$email,$phone,$id]);
    }
    header('Location: officers.php?success=Officer updated successfully'); exit;
  } catch (Exception $e) {
    header('Location: officers.php?error=Failed to update officer'); exit;
  }
}
if($action === 'delete'){
  $id = (int)($_POST['officer_id']??0);
  if($id){
    $stmt = $pdo->prepare('DELETE FROM officers WHERE officer_id=?');
    $stmt->execute([$id]);
  }
  header('Location: officers.php'); exit;
}

header('Location: officers.php'); exit;
