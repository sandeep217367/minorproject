<?php
// Diagnostic for admin login issues
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require 'config/db.php';

echo "<h2>Admin status diagnostic</h2>";

// Check file existence
$loginPath = __DIR__ . '/admin_login.php';
echo '<p>admin_login.php file: ' . (file_exists($loginPath) ? 'FOUND' : 'MISSING') . '</p>';

// Check DB connection (already required) and list admin tables
try{
  $tables = $pdo->query("SHOW TABLES LIKE 'admins'")->fetchAll();
  $hasAdmins = count($tables) > 0;
  echo '<p>admins table: ' . ($hasAdmins ? 'exists' : 'missing') . '</p>';
  $tables = $pdo->query("SHOW TABLES LIKE 'admin'")->fetchAll();
  $hasAdmin = count($tables) > 0;
  echo '<p>admin (legacy) table: ' . ($hasAdmin ? 'exists' : 'missing') . '</p>';

  if($hasAdmins){
    $cnt = $pdo->query('SELECT COUNT(*) FROM admins')->fetchColumn();
    echo '<p>admins rows: '.intval($cnt).'</p>';
  }
  if($hasAdmin){
    $cnt = $pdo->query('SELECT COUNT(*) FROM admin')->fetchColumn();
    echo '<p>admin rows: '.intval($cnt).'</p>';
  }
}catch(Exception $e){
  echo '<p>DB error: '.htmlspecialchars($e->getMessage()).'</p>';
}

echo '<p>Open <a href="admin_login.php">admin_login.php</a> to test the login page.</p>';

?>
