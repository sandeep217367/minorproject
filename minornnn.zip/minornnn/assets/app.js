document.addEventListener('DOMContentLoaded', ()=>{
  // small helper to fetch JSON
  window.fetchJSON = async (url, opts={})=>{
    const res = await fetch(url, opts);
    return res.json();
  }
  // Debug: ensure nav links navigate — attach click handler to log and fallback
  document.querySelectorAll('.nav a').forEach(a=>{
    a.addEventListener('click', (e)=>{
      // allow normal behavior but log for debug
      console.log('Nav click:', a.getAttribute('href'));
    });
  });
  // Nav toggle for small screens
  const navToggle = document.getElementById('navToggle');
  const mainNav = document.getElementById('mainNav');
  if(navToggle && mainNav){
    navToggle.addEventListener('click', ()=> mainNav.classList.toggle('show'));
  }
  // Quick-file modal
  const quickBtn = document.getElementById('quickFileBtn');
  const quickModal = document.getElementById('quickFileModal');
  const quickClose = document.getElementById('quickFileClose');
  if(quickBtn && quickModal){
    quickBtn.addEventListener('click', ()=>{ quickModal.classList.remove('hidden'); quickModal.classList.add('show'); });
  }
  if(quickClose && quickModal){ quickClose.addEventListener('click', ()=>{ quickModal.classList.remove('show'); quickModal.classList.add('hidden'); }) }
  const quickSubmit = document.getElementById('quickFileSubmit');
  if(quickSubmit){
    quickSubmit.addEventListener('click', ()=>{
      const cat = encodeURIComponent(document.getElementById('quickCat').value||'');
      const desc = encodeURIComponent(document.getElementById('quickDesc').value||'');
      // redirect to the full file page with query params so user can confirm and submit
      window.location = `file_complaint.php?category=${cat}&desc=${desc}`;
    });
  }
  // role toggle on login card
  document.querySelectorAll('.role-btn').forEach(b=>{
    b.addEventListener('click', ()=>{
      document.querySelectorAll('.role-btn').forEach(x=>x.classList.remove('active'));
      b.classList.add('active');
      const role = b.getAttribute('data-role');
      const input = document.getElementById('roleInput'); if(input) input.value = role;
    });
  });

  // Attach refresh handlers for homepage sections (if present)
  const refreshRatings = document.getElementById('refreshRatings');
  const refreshResolved = document.getElementById('refreshResolved');
  if(refreshRatings) refreshRatings.addEventListener('click', fetchRatings);
  if(refreshResolved) refreshResolved.addEventListener('click', fetchResolved);
});

async function fetchRatings(){
  try{
    const j = await fetchJSON('index.php?ajax=ratings');
    const container = document.querySelector('.rating-list');
    if(!j.ok) return;
    container.innerHTML = '';
    const r = j.ratings || {};
    if(Object.keys(r).length===0){ container.innerHTML = '<p>No ratings yet.</p>'; return; }
    for(const k in r){
      const div = document.createElement('div'); div.className='rating-item'; div.innerHTML = `<strong>${escapeHtml(k)}</strong> <span>${escapeHtml(r[k])} ★</span>`; container.appendChild(div);
    }
  }catch(e){ console.error(e); }
}

async function fetchResolved(){
  try{
    const j = await fetchJSON('index.php?ajax=resolved');
    const container = document.querySelector('.carousel');
    if(!j.ok) return;
    container.innerHTML = '';
    const items = j.resolved || [];
    if(items.length===0){ container.innerHTML = '<p>No resolved complaints yet.</p>'; return; }
    for(const it of items){
      const art = document.createElement('article'); art.className='card';
      art.innerHTML = `<h3>${escapeHtml(it.category||'Untitled')}</h3><p>${escapeHtml(it.remarks||'Summary not provided')}</p><p class="muted">Resolved on ${escapeHtml(it.updated_at||'')} by ${escapeHtml(it.user_name||'')}</p>`;
      container.appendChild(art);
    }
  }catch(e){ console.error(e); }
}

function escapeHtml(s){ return (s||'').toString().replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":"&#39;"})[c]); }

// Render a simple progress bar into an element
function renderProgress(el, status){
  const map = { 'Pending':10, 'In Progress':60, 'Resolved':100 };
  const pct = map[status]||0;
  el.innerHTML = `<div style="background:#e6eefc;border-radius:8px;padding:6px"><div style="width:${pct}%;background:var(--accent);color:#fff;padding:8px;border-radius:6px;text-align:center">${status} ${pct}%</div></div>`;
}

// Enhance dashboard interactivity: filtering and search
document.addEventListener('DOMContentLoaded', ()=>{
  const filters = document.querySelectorAll('.filter-btn');
  const list = document.getElementById('complaintsList');
  const search = document.getElementById('searchInput');

  function applyFilter(){
    const active = document.querySelector('.filter-btn.active');
    const status = active ? active.getAttribute('data-status') : '';
    const q = search ? search.value.toLowerCase().trim() : '';
    document.querySelectorAll('#complaintsList .card-complaint, #complaintsList .card-complaint, #complaintsList article').forEach(item=>{
      const itemStatus = (item.getAttribute('data-status')||'').toLowerCase();
      const desc = (item.getAttribute('data-description')||'').toLowerCase();
      const matchesStatus = !status || itemStatus === status.toLowerCase();
      const matchesQuery = !q || desc.indexOf(q)!==-1;
      item.style.display = (matchesStatus && matchesQuery) ? '' : 'none';
    });
  }

  filters.forEach(b=>{
    b.addEventListener('click', ()=>{
      filters.forEach(x=>x.classList.remove('active'));
      b.classList.add('active');
      applyFilter();
    });
    // initialize active if it's the 'All' button
    if(b.getAttribute('data-status')==='') b.classList.add('active');
  });

  if(search){
    search.addEventListener('input', ()=>applyFilter());
  }

  // render progress bars for each complaint
  document.querySelectorAll('.progress-target').forEach(div=>{
    const id = div.getAttribute('data-id');
    // id format: p{complaint_id}
    const statusHolder = div.closest('.card-complaint') || div.closest('article');
    const status = statusHolder ? statusHolder.getAttribute('data-status') : '';
    renderProgress(div, status);
  });
  applyFilter();
});
