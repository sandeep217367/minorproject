<?php
require __DIR__ . '/config/db.php';

try{
    echo "ADMINS COLUMNS:\n";
    $cols = $pdo->query('SHOW COLUMNS FROM admins')->fetchAll();
    print_r($cols);
    echo "\nOFFICERS COLUMNS:\n";
    $cols2 = $pdo->query('SHOW COLUMNS FROM officers')->fetchAll();
    print_r($cols2);
} catch (Exception $e){
    echo "Error: " . $e->getMessage();
}

?>