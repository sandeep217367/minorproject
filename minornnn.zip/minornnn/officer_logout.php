<?php
session_start();
unset($_SESSION['officer_id'], $_SESSION['officer_name']);
header('Location: index.php'); exit;
