<?php
require 'config/db.php';
$errors = [];
if($_SERVER['REQUEST_METHOD']==='POST'){
  $username = trim($_POST['username']??'');
  $pw = $_POST['password']??'';
  $pw2 = $_POST['password2']??'';
  if(!$username||!$pw) $errors[]='Please fill required fields.';
  if($pw!==$pw2) $errors[]='Passwords do not match.';
  if(empty($errors)){
    $hash = password_hash($pw, PASSWORD_DEFAULT);
    // Insert into legacy admin table if exists, else into admins
    $hasAdmin = $pdo->query("SHOW TABLES LIKE 'admin'")->fetchColumn();
    if($hasAdmin){
      $stmt = $pdo->prepare('INSERT INTO admin (username,password) VALUES (?,?)');
      try{ $stmt->execute([$username,$hash]); header('Location: admin_login.php?registered=1'); exit; }catch(Exception $e){ $errors[]='Could not create admin. Error: ' . $e->getMessage(); }
    } else {
      $email = strpos($username, '@') === false ? $username . '@example.com' : $username;
      $stmt = $pdo->prepare('INSERT INTO admins (name,email,password) VALUES (?,?,?)');
      try {
        $stmt->execute([$username, $email, $hash]);
        header('Location: admin_login.php?registered=1');
        exit;
      } catch (Exception $e) {
        if ($e->getCode() == 23000) {
          $errors[] = 'Email already exists. Please use a different email.';
        } else {
          $errors[] = 'Could not create admin. Error: ' . $e->getMessage();
        }
      }
    }
  }
}
?>
<!doctype html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Admin Register</title><link rel="stylesheet" href="assets/style.css"></head>
<body>
<?php include __DIR__ . '/inc/header.php'; ?>
<main class="dashboard-wrap" style="text-align:left; background-image:url('assets/images/hero-bg.svg'); background-size:cover; background-position:center;">
  <div class="form" style="max-width:580px;margin:1rem auto">
    <h2>Admin Register</h2>
    <?php foreach($errors as $e) echo '<p style="color:red">'.esc($e).'</p>'; ?>
    <form method="post">
      <label>Username</label><input name="username" required>
      <label>Password</label><input name="password" type="password" required>
      <label>Confirm Password</label><input name="password2" type="password" required>
      <div style="margin-top:.6rem"><button class="btn">Create Admin</button></div>
    </form>
  </div>
</main>
<?php include __DIR__ . '/inc/footer.php'; ?>
</body></html>
