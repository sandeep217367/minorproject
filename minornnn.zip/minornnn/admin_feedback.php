<?php
require 'config/db.php';
session_start();
if(empty($_SESSION['admin_id'])){
    header('Location: admin_login.php');
    exit;
}

// Join with complaints and users tables to get user names
$stmt = $pdo->query('
    SELECT f.*, c.user_id, u.name as user_name 
    FROM feedback f 
    LEFT JOIN complaints c ON f.complaint_id = c.complaint_id
    LEFT JOIN users u ON c.user_id = u.user_id 
    ORDER BY f.date_given DESC
');
$feedbacks = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Admin Feedback</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<?php include 'inc/header.php'; ?>
<main class="dashboard-wrap">
    <div class="feedback-container">
        <h2>Feedback</h2>
        <table class="feedback-table">
            <thead>
                <tr>
                    <th>Complaint ID</th>
                    <th>Rating</th>
                    <th>Comments</th>
                    <th>Date</th>
                    <th>User</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($feedbacks as $feedback): ?>
                <tr>
                    <td>
                        <?php
                        $complaintId = $feedback['complaint_id'];
                        echo 'CTRT-' . str_pad($complaintId, 6, '0', STR_PAD_LEFT);
                        ?>
                    </td>
                    <td><?= htmlspecialchars($feedback['rating']) ?></td>
                    <td><?= htmlspecialchars($feedback['comments']) ?></td>
                    <td><?= htmlspecialchars($feedback['date_given']) ?></td>
                    <td><?= htmlspecialchars($feedback['user_name'] ?? 'Unknown') ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</main>

<style>
<?php include __DIR__ . '/inc/footer.php'; ?>
</body>
</html>
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    margin: 20px auto;
    max-width: 900px;
}
.feedback-container h2 {
    text-align: center;
    margin-bottom: 20px;
    font-size: 24px;
    color: #333;
}
.feedback-table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 20px;
}
.feedback-table th, .feedback-table td {
    border: 1px solid #ddd;
    padding: 10px;
    text-align: center;
    font-size: 16px;
}
.feedback-table th {
    background-color: #007bff;
    color: white;
}
.feedback-table tr:nth-child(even) {
    background-color: #f9f9f9;
}
.feedback-table tr:hover {
    background-color: #f1f1f1;
}
</style>
</body>
</html>