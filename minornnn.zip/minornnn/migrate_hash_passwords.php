<?php
require __DIR__ . '/config/db.php';

function looks_hashed($s){
    if(!$s) return false;
    // bcrypt / argon2 checks
    if(preg_match('/^\$2[aby]\$\d{2}\$/', $s)) return true;
    if(strpos($s, '$argon2') === 0) return true;
    return false;
}

try{
    echo "Checking admins...\n";
    $admins = $pdo->query('SELECT admin_id,password,email FROM admins')->fetchAll();
    foreach($admins as $a){
        $pw = $a['password'];
        if(!looks_hashed($pw)){
            $new = password_hash($pw, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare('UPDATE admins SET password = ? WHERE admin_id = ?');
            $stmt->execute([$new, $a['admin_id']]);
            echo "Updated admin {$a['email']} ({$a['admin_id']})\n";
        } else {
            echo "Skipped (already hashed) admin {$a['email']} ({$a['admin_id']})\n";
        }
    }

    echo "\nChecking officers...\n";
    // make sure column exists
    try{ $pdo->query("SELECT password_hash FROM officers LIMIT 1"); } catch(Exception $e){
        echo "Officers table missing password_hash column; attempting to add it...\n";
        try{ $pdo->exec("ALTER TABLE officers ADD COLUMN password_hash VARCHAR(255) DEFAULT NULL"); echo "Added column.\n"; } catch(Exception $ex){ echo "Failed to add column: " . $ex->getMessage() . "\n"; }
    }
    $offs = $pdo->query('SELECT officer_id,password_hash,email FROM officers')->fetchAll();
    foreach($offs as $o){
        $ph = $o['password_hash'];
        if(!looks_hashed($ph) && !empty($ph)){
            $new = password_hash($ph, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare('UPDATE officers SET password_hash = ? WHERE officer_id = ?');
            $stmt->execute([$new, $o['officer_id']]);
            echo "Updated officer {$o['email']} ({$o['officer_id']})\n";
        } else {
            echo "Skipped officer {$o['email']} ({$o['officer_id']})\n";
        }
    }

    echo "\nMigration complete.\n";
} catch(Exception $e){
    echo "Error: " . $e->getMessage() . "\n";
}

?>