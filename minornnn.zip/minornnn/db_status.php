<?php
// Diagnostic: list tables and columns for the complaint_tracker database
require 'config/db.php';
header('Content-Type: text/plain');
try{
    $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    echo "Connected to DB. Tables found:\n\n";
    foreach($tables as $t){
        echo "Table: $t\n";
        $cols = $pdo->query("SHOW COLUMNS FROM `$t`")->fetchAll(PDO::FETCH_ASSOC);
        foreach($cols as $c){
            echo "  - {$c['Field']} ({$c['Type']})\n";
        }
        echo "\n";
    }
}catch(Exception $e){
    echo "DB error: " . $e->getMessage() . "\n";
}

?>