# Complaint-to-Resolution Transparency Tracker

Simple PHP/MySQL application for filing and tracking complaints.

Requirements
- XAMPP (Apache + PHP + MySQL)
- PHP 7.4+ (PDO enabled)

Installation
1. Copy the `minor` folder into your `htdocs` (already placed at `d:/xampp/htdocs/minor`).
2. Start Apache and MySQL via XAMPP Control Panel.
3. If your existing database schema differs (you saw errors like "Unknown column 'c.title'"), run the migration script I included to adapt your current schema to the app's expectations.

Backup first (strongly recommended):
Using PowerShell (adjust path/user as needed):
```powershell
& 'd:\xampp\mysql\bin\mysqldump.exe' -u root -p complaint_tracker > d:\backup_complaint_tracker.sql
```

Run migration (phpMyAdmin or CLI):
- phpMyAdmin: Import `db/migrate_to_app_schema.sql` into the `complaint_tracker` database.
- CLI (PowerShell):
```powershell
& 'd:\xampp\mysql\bin\mysql.exe' -u root -p complaint_tracker < d:\xampp\htdocs\minor\db\migrate_to_app_schema.sql
```

4. Update DB credentials in `config/db.php` if needed.
5. Open http://localhost/minor in your browser.

Notes
- This is a starter implementation demonstrating core features. For production, harden authentication, file upload handling, input validation, and use HTTPS.
