<?php
require_once 'config/db.php';

try {
    $stmt = $pdo->prepare("INSERT INTO admins (name, email, password) VALUES ('Test Admin', 'testadmin@example.com', 'testpassword')");
    $stmt->execute();
    echo "Test admin registered successfully.";
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
