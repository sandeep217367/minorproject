<?php
require 'config/db.php';
session_start();
// ensure officers table exists
$pdo->exec("CREATE TABLE IF NOT EXISTS officers (
  officer_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(191) NOT NULL,
  department VARCHAR(191) DEFAULT NULL,
  email VARCHAR(191) DEFAULT NULL,
  phone VARCHAR(50) DEFAULT NULL,
  password_hash VARCHAR(255) DEFAULT NULL
)");

$hasAdmin = !empty($_SESSION['admin_id']);
$officers = $pdo->query('SELECT * FROM officers ORDER BY name')->fetchAll();

// If an edit query param is present, load that officer for editing
$editOfficer = null;
if (!empty($_GET['edit'])) {
  $eid = (int)$_GET['edit'];
  $stmt = $pdo->prepare('SELECT * FROM officers WHERE officer_id = ?');
  $stmt->execute([$eid]);
  $editOfficer = $stmt->fetch();
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Officers</title>
  <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<?php include __DIR__ . '/inc/header.php'; ?>
<main class="dashboard-wrap">
  <div class="panel">
    <div class="panel-header"><h2>Officers</h2>
      <div class="panel-actions">
        <?php if($hasAdmin): ?><a href="admin_dashboard.php" class="btn">Back</a><?php endif; ?>
      </div>
    </div>

    <p class="muted">Manage officers who can be assigned complaints.</p>

    <?php if($hasAdmin): ?>
      <div class="form" style="margin-bottom:1rem">
        <h3>Add Officer</h3>
        <form method="post" action="officers_actions.php">
          <input type="hidden" name="action" value="create">
          <label>Name</label><input name="name" required>
          <label>Department</label><input name="department">
          <label>Email</label><input name="email" type="email">
          <label>Phone</label><input name="phone">
          <label>Password (optional)</label><input name="password" type="password" placeholder="Set a password for officer">
          <div style="margin-top:.6rem"><button class="btn" type="submit">Create</button></div>
        </form>
      </div>

      <?php if($editOfficer): ?>
        <div class="form" style="margin-bottom:1rem">
          <h3>Edit Officer</h3>
          <form method="post" action="officers_actions.php">
            <input type="hidden" name="action" value="update">
            <input type="hidden" name="officer_id" value="<?=esc($editOfficer['officer_id'])?>">
            <label>Name</label><input name="name" required value="<?=esc($editOfficer['name'])?>">
            <label>Department</label><input name="department" value="<?=esc($editOfficer['department'])?>">
            <label>Email</label><input name="email" type="email" value="<?=esc($editOfficer['email'])?>">
            <label>Phone</label><input name="phone" value="<?=esc($editOfficer['phone'])?>">
            <label>Password (leave blank to keep current)</label><input name="password" type="password" placeholder="Leave blank to keep password">
            <div style="margin-top:.6rem">
              <button class="btn" type="submit">Save</button>
              <a href="officers.php" class="btn" style="margin-left:.5rem">Cancel</a>
            </div>
          </form>
        </div>
      <?php endif; ?>
    <?php endif; ?>

    <div class="table-card">
      <table class="admin-table">
        <thead><tr><th>Name</th><th>Department</th><th>Email</th><th>Phone</th><?php if($hasAdmin): ?><th>Actions</th><?php endif; ?></tr></thead>
        <tbody>
          <?php foreach($officers as $o): ?>
            <tr>
              <td><?=esc($o['name'])?></td>
              <td><?=esc($o['department'])?></td>
              <td><?=esc($o['email'])?></td>
              <td><?=esc($o['phone'])?></td>
              <?php if($hasAdmin): ?>
                <td>
                  <a href="officers.php?edit=<?=esc($o['officer_id'])?>" class="btn small" style="margin-right:.4rem">Edit</a>
                  <form method="post" action="officers_actions.php" style="display:inline">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="officer_id" value="<?=esc($o['officer_id'])?>">
                    <button class="btn small" type="submit" onclick="return confirm('Delete this officer?')">Delete</button>
                  </form>
                </td>
              <?php endif; ?>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</main>
<?php include __DIR__ . '/inc/footer.php'; ?>
</body>
</html>
