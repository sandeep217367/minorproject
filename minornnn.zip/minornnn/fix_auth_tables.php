<?php
require __DIR__ . '/config/db.php';
header('Content-Type: text/plain');

try {
    // 1. Create or fix admins table
    $pdo->exec("CREATE TABLE IF NOT EXISTS admins (
        admin_id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(191) NOT NULL,
        email VARCHAR(191) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");
    echo "Ensured admins table exists with correct structure\n";

    // 2. Create or fix officers table
    $pdo->exec("CREATE TABLE IF NOT EXISTS officers (
        officer_id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(191) NOT NULL,
        department VARCHAR(191) DEFAULT NULL,
        email VARCHAR(191) UNIQUE,
        phone VARCHAR(50) DEFAULT NULL,
        password_hash VARCHAR(255) DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");
    echo "Ensured officers table exists with correct structure\n";

    // 3. Create or fix users table
    $pdo->exec("CREATE TABLE IF NOT EXISTS users (
        user_id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(191) NOT NULL,
        email VARCHAR(191) UNIQUE NOT NULL,
        phone VARCHAR(50) DEFAULT NULL,
        password VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");
    echo "Ensured users table exists with correct structure\n";

    // 4. Add a test admin if none exists
    $adminCount = $pdo->query("SELECT COUNT(*) FROM admins")->fetchColumn();
    if ($adminCount == 0) {
        $hash = password_hash('admin123', PASSWORD_DEFAULT);
        $pdo->exec("INSERT INTO admins (name, email, password) VALUES ('Administrator', 'admin@example.com', '$hash')");
        echo "\nCreated default admin account:\nEmail: admin@example.com\nPassword: admin123\n";
    }

    // 5. Show table counts
    echo "\nCurrent record counts:\n";
    echo "Admins: " . $pdo->query("SELECT COUNT(*) FROM admins")->fetchColumn() . "\n";
    echo "Officers: " . $pdo->query("SELECT COUNT(*) FROM officers")->fetchColumn() . "\n";
    echo "Users: " . $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn() . "\n";

    // 6. Migrate any plaintext passwords to hashed
    $admins = $pdo->query("SELECT admin_id, password FROM admins")->fetchAll();
    foreach($admins as $admin) {
        if (!password_get_info($admin['password'])['algo']) {
            // Password is not hashed
            $hash = password_hash($admin['password'], PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE admins SET password = ? WHERE admin_id = ?");
            $stmt->execute([$hash, $admin['admin_id']]);
            echo "Migrated plaintext password for admin ID {$admin['admin_id']}\n";
        }
    }

    echo "\nDatabase structure fixed successfully.\n";
} catch(Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>