<?php
require 'config/db.php';
session_start();
$errors = [];
if($_SERVER['REQUEST_METHOD']==='POST'){
  $role = $_POST['role']??'user';
  $login = trim($_POST['email']??'');
  $pw = $_POST['password']??'';
  if($role === 'admin'){
    // attempt admin auth using 'admins' table if it exists, else fallback to legacy 'admin' table
    $a = false;
    try{
      $hasAdmins = (bool)$pdo->query("SHOW TABLES LIKE 'admins'")->fetchColumn();
    }catch(Exception $e){ $hasAdmins = false; }
    if($hasAdmins){
      $stmt = $pdo->prepare('SELECT * FROM admins WHERE email=?');
      $stmt->execute([$login]); $a = $stmt->fetch();
    }
    // fallback to legacy admin table
    if(!$a){
      try{ $hasLegacy = (bool)$pdo->query("SHOW TABLES LIKE 'admin'")->fetchColumn(); }catch(Exception $e){ $hasLegacy = false; }
      if($hasLegacy){
        $stmt = $pdo->prepare('SELECT * FROM admin WHERE username=?');
        $stmt->execute([$login]); $a = $stmt->fetch();
        if($a){
          // normalize field names if necessary
          if(!isset($a['admin_id']) && isset($a['id'])) $a['admin_id'] = $a['id'];
          $a['name'] = $a['username'] ?? ($a['name'] ?? '');
        }
      }
    }
    if($a && isset($a['password']) && password_verify($pw, $a['password'])){
      $_SESSION['admin_id'] = $a['admin_id'];
      $_SESSION['admin_name'] = $a['name'];
      header('Location: admin_dashboard.php'); exit;
    }
    $errors[] = 'Invalid admin credentials';
  } else {
    if($role === 'officer'){
      // officer login
      try{ $hasOfficers = (bool)$pdo->query("SHOW TABLES LIKE 'officers'")->fetchColumn(); }catch(Exception $e){ $hasOfficers = false; }
      if($hasOfficers){
        $stmt = $pdo->prepare('SELECT officer_id,name,password_hash FROM officers WHERE email = ? LIMIT 1');
        $stmt->execute([$login]); $o = $stmt->fetch();
        if($o && !empty($o['password_hash']) && password_verify($pw, $o['password_hash'])){
          $_SESSION['officer_id'] = $o['officer_id'];
          $_SESSION['officer_name'] = $o['name'];
          header('Location: officer_dashboard.php'); exit;
        }
      }
      $errors[] = 'Invalid officer credentials';
    } else {
    // user login path (email or mobile/phone)
    $stmt = $pdo->prepare('SELECT * FROM users WHERE email=?');
    $stmt->execute([$login]);
    $u = $stmt->fetch();
    if(!$u){
      $hasMobile = (bool)$pdo->query("SHOW COLUMNS FROM users LIKE 'mobile'")->fetchColumn();
      $hasPhone = (bool)$pdo->query("SHOW COLUMNS FROM users LIKE 'phone'")->fetchColumn();
      if($hasMobile && $hasPhone){
        $stmt = $pdo->prepare('SELECT * FROM users WHERE mobile=? OR phone=?');
        $stmt->execute([$login,$login]);
        $u = $stmt->fetch();
      } elseif($hasMobile){
        $stmt = $pdo->prepare('SELECT * FROM users WHERE mobile=?'); $stmt->execute([$login]); $u = $stmt->fetch();
      } elseif($hasPhone){
        $stmt = $pdo->prepare('SELECT * FROM users WHERE phone=?'); $stmt->execute([$login]); $u = $stmt->fetch();
      }
    }
    if($u && password_verify($pw, $u['password'])){
      $_SESSION['user_id'] = $u['user_id'];
      $_SESSION['name'] = $u['name'];
      header('Location: user_dashboard.php'); exit;
    }
    $errors[] = 'Invalid user credentials';
    }
  }
}
?>
<!doctype html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Login</title><link rel="stylesheet" href="assets/style.css"></head>
<body>
<?php include __DIR__ . '/inc/header.php'; ?>
<div class="login-container">
  <div class="login-card">
    <h2 class="login-title">Login</h2>
    <p class="login-sub">Sign in to access your account</p>
    <?php if(isset($_GET['registered'])) echo '<p style="color:green; text-align:center">Registration successful. Please login.</p>'; ?>
    <?php if($errors) foreach($errors as $e) echo '<p style="color:red; text-align:center">'.esc($e).'</p>'; ?>

    <div class="role-toggle">
      <button type="button" data-role="user" class="role-btn active" onclick="setRole('user', this)">User</button>
      <button type="button" data-role="officer" class="role-btn" onclick="setRole('officer', this)">Officer</button>
      <button type="button" data-role="admin" class="role-btn" onclick="setRole('admin', this)">Admin</button>
    </div>

    <form method="post" id="loginForm">
      <input type="hidden" name="role" id="roleInput" value="user">
      <label>Email or Mobile</label>
      <input name="email" type="text" placeholder="Email or phone" required>
      <label>Password</label>
      <input name="password" type="password" placeholder="Password" required>
      <div style="margin-top:.6rem"><button class="btn" type="submit">Login</button></div>
    </form>

    <div class="login-links">
      <a href="register.php">Register here</a>
      <a href="admin_register.php">Admin Register</a>
    </div>
  </div>
  </div>
<?php include __DIR__ . '/inc/footer.php'; ?>
<script>
// Inline fallback so role toggle works even if assets/app.js fails to load
function setRole(role, btn){
  var input = document.getElementById('roleInput'); if(input) input.value = role;
  document.querySelectorAll('.role-btn').forEach(function(x){ x.classList.remove('active'); });
  if(btn) btn.classList.add('active');
}
</script>
</body></html>
