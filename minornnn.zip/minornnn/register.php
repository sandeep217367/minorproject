<?php
require 'config/db.php';
$errors = [];
if($_SERVER['REQUEST_METHOD']==='POST'){
  $name = trim($_POST['name']??'');
  $email = trim($_POST['email']??'');
  $phone = trim($_POST['phone']??'');
  $pw = $_POST['password']??'';
  $pw2 = $_POST['confirm_password']??'';
  if(!$name||!$email||!$pw) $errors[]='Please fill required fields.';
  if($pw!==$pw2) $errors[]='Passwords do not match.';
  if(empty($errors)){
    $hash = password_hash($pw, PASSWORD_DEFAULT);
    try{
      // detect if `mobile` column exists (older schema)
      $hasMobile = $pdo->query("SHOW COLUMNS FROM users LIKE 'mobile'")->fetchColumn();
      if($hasMobile){
        $stmt = $pdo->prepare('INSERT INTO users (name,email,mobile,password) VALUES (?,?,?,?)');
        $stmt->execute([$name,$email,$phone,$hash]);
      } else {
        $stmt = $pdo->prepare('INSERT INTO users (name,email,phone,password) VALUES (?,?,?,?)');
        $stmt->execute([$name,$email,$phone,$hash]);
      }
      header('Location: login.php?registered=1');exit;
    }catch(Exception $e){ $errors[] = 'Email already registered. DB: ' . $e->getMessage(); }
  }
}
?>
<!doctype html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Register</title><link rel="stylesheet" href="assets/style.css"></head>
<body>
<?php include __DIR__ . '/inc/header.php'; ?>
<main class="dashboard-wrap" style="text-align:left; background-image:url('assets/images/hero-bg.svg'); background-size:cover; background-position:center;">
  <div class="form" style="max-width:580px;margin:1rem auto">
    <h2>Register</h2>
    <?php if($errors) foreach($errors as $e) echo '<p style="color:red">'.esc($e).'</p>'; ?>
    <form method="post">
      <label>Name</label><input name="name" required>
      <label>Email</label><input name="email" type="email" required>
      <label>Phone</label><input name="phone">
      <label>Password</label><input name="password" type="password" required>
      <label>Confirm Password</label><input name="confirm_password" type="password" required>
      <div style="margin-top:.6rem"><button class="btn" type="submit">Register</button></div>
      <div style="display:flex;justify-content:space-between;margin-top:1rem">
        <a href="login.php">Login</a>
        <a href="admin_register.php">Admin Register</a>
      </div>
    </form>
  </div>
</main>
<?php include __DIR__ . '/inc/footer.php'; ?>
</body></html>
