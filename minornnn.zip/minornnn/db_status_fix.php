<?php
require_once __DIR__ . '/../config/db.php';

$requiredColumns = [
    'category' => 'VARCHAR(191) DEFAULT NULL',
    'remarks' => 'TEXT DEFAULT NULL',
    'updated_at' => 'DATETIME DEFAULT NULL',
    'evidence_file' => 'VARCHAR(255) DEFAULT NULL',
    'assigned_to' => 'INT DEFAULT NULL',
    'status' => "VARCHAR(50) DEFAULT 'Pending'",
    'created_at' => 'DATETIME DEFAULT CURRENT_TIMESTAMP',
];

$table = 'complaints';
$existing = $pdo->query("SHOW COLUMNS FROM $table")->fetchAll(PDO::FETCH_COLUMN, 0);
$added = [];
foreach ($requiredColumns as $col => $def) {
    if (!in_array($col, $existing)) {
        $pdo->exec("ALTER TABLE $table ADD COLUMN $col $def");
        $added[] = $col;
    }
}

if ($added) {
    echo "Added missing columns: " . implode(', ', $added) . "<br>";
} else {
    echo "All required columns already exist.<br>";
}

// Show final schema
$res = $pdo->query("SHOW COLUMNS FROM $table");
echo '<h3>complaints table columns:</h3><ul>';
foreach ($res as $row) {
    echo '<li>' . htmlspecialchars($row['Field']) . ' - ' . htmlspecialchars($row['Type']) . '</li>';
}
echo '</ul>';
?>