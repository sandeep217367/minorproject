<?php
require_once __DIR__ . '/config/db.php';
$table = 'users';
$col = 'created_at';
$exists = false;
$res = $pdo->query("SHOW COLUMNS FROM $table");
foreach ($res as $row) {
    if ($row['Field'] === $col) {
        $exists = true;
        break;
    }
}
if (!$exists) {
    $pdo->exec("ALTER TABLE $table ADD COLUMN $col DATETIME DEFAULT CURRENT_TIMESTAMP");
    echo "Column 'created_at' added to users table.<br>";
} else {
    echo "Column 'created_at' already exists in users table.<br>";
}
?>