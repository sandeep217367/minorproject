<?php
require 'config/db.php';
session_start();
header('Content-Type: application/json');
if(empty($_SESSION['officer_id'])){ http_response_code(401); echo json_encode(['ok'=>false,'message'=>'Unauthorized']); exit; }
$officer_id = $_SESSION['officer_id'];

$body = json_decode(file_get_contents('php://input'), true) ?? $_POST;
$action = $body['action'] ?? '';
if($action === 'update_status'){
  $cid = (int)($body['complaint_id'] ?? 0);
  $status = trim($body['status'] ?? '');
  $remarks = trim($body['remarks'] ?? '');
  if(!$cid || !$status){ echo json_encode(['ok'=>false,'message'=>'Invalid']); exit; }
  // verify ownership
  $stmt = $pdo->prepare('SELECT assigned_to FROM complaints WHERE complaint_id=? LIMIT 1');
  $stmt->execute([$cid]); $row = $stmt->fetch();
  if(!$row || (int)$row['assigned_to'] !== (int)$officer_id){ http_response_code(403); echo json_encode(['ok'=>false,'message'=>'Not allowed']); exit; }
  // append remarks safely
  if($remarks){
    // Use proper escaping for nested single quotes
    $stmt = $pdo->prepare("UPDATE complaints SET status=?, remarks=CONCAT(IFNULL(remarks,''), ?, ?) , updated_at=NOW() WHERE complaint_id=?");
    // prepend a newline and officer name/time
    $prefix = "\n[Officer: " . ($_SESSION['officer_name'] ?? 'officer') . " @ " . date('Y-m-d H:i:s') . "] ";
    $stmt->execute([$status, $prefix, $remarks, $cid]);
  } else {
    $stmt = $pdo->prepare('UPDATE complaints SET status=?, updated_at=NOW() WHERE complaint_id=?');
    $stmt->execute([$status,$cid]);
  }
  echo json_encode(['ok'=>true,'message'=>'Updated']); exit;
}

if($action === 'edit_officer') {
  $officer_id_to_edit = (int)($body['officer_id'] ?? 0);
  $name = trim($body['name'] ?? '');
  $department = trim($body['department'] ?? '');
  $contact = trim($body['contact'] ?? '');
  $email = trim($body['email'] ?? '');
  $phone = trim($body['phone'] ?? '');

  if (!$officer_id_to_edit || !$name || !$email) {
    echo json_encode(['ok' => false, 'message' => 'Invalid input']);
    exit;
  }

  try {
    $stmt = $pdo->prepare('UPDATE officers SET name = ?, department = ?, contact = ?, email = ?, phone = ? WHERE officer_id = ?');
    $stmt->execute([$name, $department, $contact, $email, $phone, $officer_id_to_edit]);
    echo json_encode(['ok' => true, 'message' => 'Officer details updated successfully']);
  } catch (Exception $e) {
    echo json_encode(['ok' => false, 'message' => 'Error updating officer: ' . $e->getMessage()]);
  }
  exit;
}

echo json_encode(['ok'=>false,'message'=>'Unknown action']); exit;
