<?php
require_once __DIR__ . '/config/db.php';

$table = 'officers';
$columns = [
    'email' => 'VARCHAR(191) DEFAULT NULL',
    'phone' => 'VARCHAR(50) DEFAULT NULL',
    'password_hash' => 'VARCHAR(255) DEFAULT NULL'
];

$existing = $pdo->query("SHOW COLUMNS FROM $table")->fetchAll(PDO::FETCH_COLUMN, 0);
$added = [];
foreach ($columns as $col => $def) {
    if (!in_array($col, $existing)) {
        $pdo->exec("ALTER TABLE $table ADD COLUMN $col $def");
        $added[] = $col;
    }
}

if ($added) {
    echo "Added missing columns: " . implode(', ', $added) . "<br>";
} else {
    echo "All required columns already exist.<br>";
}

// Show final schema
$res = $pdo->query("SHOW COLUMNS FROM $table");
echo '<h3>officers table columns:</h3><ul>';
foreach ($res as $row) {
    echo '<li>' . htmlspecialchars($row['Field']) . ' - ' . htmlspecialchars($row['Type']) . '</li>';
}
echo '</ul>';
?>