<?php
require 'config/db.php';
session_start();
// Allow only admins to delete users
if(empty($_SESSION['admin_id'])){
	// if AJAX request, return JSON
	if(!empty($_SERVER['HTTP_X_REQUESTED_WITH'])){ header('Content-Type: application/json'); echo json_encode(['ok'=>false,'error'=>'unauthorized']); exit; }
	header('Location: admin_login.php'); exit;
}
$uid = (int)($_POST['user_id']??0);
if(!$uid){ header('Content-Type: application/json'); echo json_encode(['ok'=>false,'error'=>'invalid_id']); exit; }
// Try both possible id column names to be safe
$stmt = $pdo->prepare('DELETE FROM users WHERE user_id=?');
$r = $stmt->execute([$uid]);
if(!$r){ // try alternate column
	$stmt = $pdo->prepare('DELETE FROM users WHERE id=?');
	$r = $stmt->execute([$uid]);
}
header('Content-Type: application/json'); echo json_encode(['ok'=>(bool)$r]);
?>