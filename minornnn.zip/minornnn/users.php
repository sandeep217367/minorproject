<?php
require 'config/db.php';
session_start();
if(empty($_SESSION['admin_id'])){ header('Location: admin_login.php'); exit; }
$users = $pdo->query('SELECT user_id, name, email FROM users ORDER BY user_id DESC')->fetchAll();
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Users</title>
  <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<?php include __DIR__ . '/inc/header.php'; ?>
<main class="dashboard-wrap">
  <div class="panel">
    <div class="panel-header"><h2>Users</h2><div class="panel-actions"><a href="admin_dashboard.php" class="btn">Back</a></div></div>
    <div class="table-card">
      <table class="admin-table">
        <thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Actions</th></tr></thead>
        <tbody>
          <?php foreach($users as $u): ?>
            <tr>
              <td><?=esc($u['user_id'])?></td>
              <td><?=esc($u['name'])?></td>
              <td><?=esc($u['email'])?></td>
              <td>
                <form method="post" action="delete_user.php" onsubmit="return confirm('Delete this user?');" style="display:inline">
                  <input type="hidden" name="user_id" value="<?=esc($u['user_id'])?>">
                  <button class="btn small" type="submit">Delete</button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</main>
<?php include __DIR__ . '/inc/footer.php'; ?>
</body>
</html>
