<?php
require 'config/db.php';
// If AJAX query param 'q' present, return JSON
if(isset($_GET['q'])){
  $q = trim($_GET['q']);
  if(preg_match('/^CTRT-0*(\d+)$/', $q, $m)){
    $id = (int)$m[1];
  $stmt = $pdo->prepare('SELECT c.*, u.name as user_name, u.email as user_email FROM complaints c JOIN users u ON c.user_id=u.user_id WHERE c.complaint_id=?');
    $stmt->execute([$id]);
    $data = $stmt->fetch();
    if($data) echo json_encode(['ok'=>true,'data'=>$data]); else echo json_encode(['ok'=>false,'msg'=>'Not found']);
    exit;
  } else {
    // search by email
    // search by email using existing created_at ordering
  $stmt = $pdo->prepare('SELECT c.*, u.name as user_name, u.email as user_email FROM complaints c JOIN users u ON c.user_id=u.user_id WHERE u.email=? ORDER BY c.created_at DESC LIMIT 10');
    $stmt->execute([$q]);
    $rows = $stmt->fetchAll();
    echo json_encode(['ok'=>true,'data'=>$rows]); exit;
  }
}
// If a direct id is provided show full details page
if(isset($_GET['id'])){
  $id = (int)$_GET['id'];
  $stmt = $pdo->prepare('SELECT c.*, u.name as user_name FROM complaints c LEFT JOIN users u ON c.user_id=u.user_id WHERE c.complaint_id=?');
  $stmt->execute([$id]);
  $d = $stmt->fetch();
  if(!$d){ header('Location: track.php'); exit; }
  include __DIR__ . '/inc/header.php';
  ?>
  <main class="dashboard-wrap">
    <div class="panel">
      <div class="panel-header"><h2>Complaint Details</h2><div class="panel-actions"><a href="user_dashboard.php" class="btn">Back</a></div></div>
      <div class="form">
        <h3><?=esc($d['category']?:'Untitled')?></h3>
        <p><strong>Tracking ID:</strong> CTRT-<?=str_pad($d['complaint_id'],6,'0',STR_PAD_LEFT)?></p>
        <p><strong>Filed by:</strong> <?=esc($d['user_name']??'')?> | <strong>Filed:</strong> <?=esc($d['created_at'] ?? $d['date_submitted'] ?? '')?></p>
        <p><strong>Status:</strong> <?=esc($d['status']??'')?></p>
        <p><strong>Description:</strong><br><?=nl2br(esc($d['description'] ?? $d['remarks'] ?? ''))?></p>
        <?php if(!empty($d['evidence_file'])): ?>
          <p><strong>Attachment:</strong> <a href="<?=esc($d['evidence_file'])?>" target="_blank">View</a></p>
        <?php endif; ?>
        <?php if(!empty($d['resolution_note'])): ?><p><strong>Resolution note:</strong><br><?=nl2br(esc($d['resolution_note']))?></p><?php endif; ?>
        <?php if(isset($d['assigned_to'])): ?><p><strong>Assigned to:</strong> <?=esc($d['assigned_to'])?></p><?php endif; ?>
      </div>
    </div>
  </main>
  <?php include __DIR__ . '/inc/footer.php';
  exit;
}
?>
<!doctype html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Track Complaint</title><link rel="stylesheet" href="assets/style.css"><script src="assets/app.js" defer></script></head>
<body>
<?php include __DIR__ . '/inc/header.php'; ?>
<main class="dashboard-wrap">
  <div class="form">
    <h2>Track Complaint</h2>
    <p>Enter your tracking ID (e.g. CTRT-000123) or the email used to file complaints.</p>
    <input id="q" placeholder="Tracking ID or Email">
    <div style="margin-top:.6rem"><button class="btn" onclick="doSearch()">Search</button></div>
    <div id="results" style="margin-top:1rem"></div>
  </div>
</main>
<script>
async function doSearch(){
  const q = document.getElementById('q').value.trim();
  if(!q) return;
  const res = await fetch('track.php?q='+encodeURIComponent(q));
  const j = await res.json();
  const out = document.getElementById('results'); out.innerHTML='';
  if(!j.ok){ out.textContent = 'Not found'; return; }
  const data = j.data;
  if(Array.isArray(data)){
    data.forEach(d=> renderOne(d,out));
  } else { renderOne(data,out); }
}
function renderOne(d,out){
  const div = document.createElement('div'); div.className='card';
  div.innerHTML = `<h3>${escapeHtml(d.title)}</h3><p>${escapeHtml(d.description||'')}</p><p><strong>Status:</strong> ${escapeHtml(d.status)}</p><div id='p${d.complaint_id}'></div>`;
  out.appendChild(div);
  renderProgress(div.querySelector('#p'+d.complaint_id), d.status);
}
function escapeHtml(s){return (s||'').replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":"&#39;"})[c]);}
</script>
</body></html>
