<?php
require 'config/db.php';
session_start();
if(!empty($_SESSION['officer_id'])){ header('Location: officer_dashboard.php'); exit; }
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Officer Login</title>
  <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<?php include __DIR__ . '/inc/header.php'; ?>
<main class="center-card">
  <div class="card">
    <h2>Officer Login</h2>
    <?php if(!empty($_GET['error'])): ?>
      <div style="background:#fee;border:1px solid #fbb;padding:.6rem;border-radius:6px;margin-bottom:.6rem;color:#900">Invalid credentials. Make sure the officer has a password set (admin can set/reset it in Officers).</div>
    <?php endif; ?>
    <form method="post" action="officer_login_action.php">
      <label>Email</label>
      <input name="email" type="email" required>
      <label>Password</label>
      <input name="password" type="password" required>
      <div style="margin-top:.6rem"><button class="btn" type="submit">Login</button></div>
    </form>
    <p class="muted" style="margin-top:.6rem">If you are an admin, manage officer passwords at <a href="officers.php">Officers</a>.</p>
  </div>
</main>
<?php include __DIR__ . '/inc/footer.php'; ?>
</body>
</html>
