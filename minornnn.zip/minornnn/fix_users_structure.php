<?php
require __DIR__ . '/config/db.php';
header('Content-Type: text/plain');

try {
    // 1. Update users table structure
    echo "Fixing users table structure...\n";
    
    // Drop date_created column if exists (we'll use created_at consistently)
    $hasDateCreated = $pdo->query("SHOW COLUMNS FROM users LIKE 'date_created'")->fetchColumn();
    if($hasDateCreated) {
        $pdo->exec("ALTER TABLE users DROP COLUMN date_created");
        echo "Dropped date_created column\n";
    }

    // Ensure created_at exists with correct default
    $hasCreatedAt = $pdo->query("SHOW COLUMNS FROM users LIKE 'created_at'")->fetchColumn();
    if(!$hasCreatedAt) {
        $pdo->exec("ALTER TABLE users ADD COLUMN created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP");
        echo "Added created_at column\n";
    }

    // 2. Update users table definition
    $pdo->exec("ALTER TABLE users
        MODIFY user_id INT AUTO_INCREMENT,
        MODIFY name VARCHAR(191) NOT NULL,
        MODIFY email VARCHAR(191) NOT NULL,
        MODIFY phone VARCHAR(50) DEFAULT NULL,
        MODIFY password VARCHAR(255) NOT NULL,
        MODIFY created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        ADD UNIQUE (email)");
    
    echo "\nUsers table structure updated successfully.\n";
    
    // Show final structure
    echo "\nFinal users table structure:\n";
    $cols = $pdo->query("SHOW COLUMNS FROM users")->fetchAll(PDO::FETCH_ASSOC);
    foreach($cols as $c) {
        echo "  - {$c['Field']} ({$c['Type']})" . 
             ($c['Key'] ? " [{$c['Key']}]" : "") . 
             ($c['Default'] ? " default: {$c['Default']}" : "") . "\n";
    }

} catch(Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>