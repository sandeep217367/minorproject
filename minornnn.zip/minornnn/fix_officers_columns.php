<?php
require __DIR__ . '/config/db.php';
header('Content-Type: text/plain');

try {
    echo "Current officers table structure:\n";
    $cols = $pdo->query("SHOW COLUMNS FROM officers")->fetchAll(PDO::FETCH_ASSOC);
    foreach($cols as $c){
        echo "  - {$c['Field']} ({$c['Type']})\n";
    }

    // Add missing columns if they don't exist
    $columns = [
        'email' => 'VARCHAR(191)',
        'phone' => 'VARCHAR(50)',
        'password_hash' => 'VARCHAR(255)',
        'created_at' => 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP'
    ];

    foreach ($columns as $column => $definition) {
        $exists = $pdo->query("SHOW COLUMNS FROM officers LIKE '$column'")->fetchColumn();
        if (!$exists) {
            $pdo->exec("ALTER TABLE officers ADD COLUMN $column $definition");
            echo "Added column $column\n";
        }
    }

    // Modify existing columns to match new structure
    $pdo->exec("ALTER TABLE officers 
                MODIFY name VARCHAR(191) NOT NULL,
                MODIFY department VARCHAR(191) DEFAULT NULL");

    if ($pdo->query("SHOW COLUMNS FROM officers LIKE 'contact'")->fetchColumn()) {
        // Migrate contact data to phone if exists
        $pdo->exec("UPDATE officers SET phone = contact WHERE phone IS NULL AND contact IS NOT NULL");
        $pdo->exec("ALTER TABLE officers DROP COLUMN contact");
        echo "Migrated contact column to phone and dropped it\n";
    }

    // Add unique constraint to email if not exists
    $indexes = $pdo->query("SHOW INDEXES FROM officers WHERE Column_name = 'email'")->fetchAll();
    $hasUnique = false;
    foreach ($indexes as $idx) {
        if ($idx['Non_unique'] == 0) {
            $hasUnique = true;
            break;
        }
    }
    if (!$hasUnique) {
        $pdo->exec("ALTER TABLE officers ADD UNIQUE (email)");
        echo "Added unique constraint to email column\n";
    }
    
    // Show final structure
    echo "\nFinal officers table structure:\n";
    $cols = $pdo->query("SHOW COLUMNS FROM officers")->fetchAll(PDO::FETCH_ASSOC);
    foreach($cols as $c){
        echo "  - {$c['Field']} ({$c['Type']})" . 
             ($c['Key'] ? " [{$c['Key']}]" : "") . 
             ($c['Default'] ? " default: {$c['Default']}" : "") . "\n";
    }

    echo "\nOfficers table updated successfully.\n";
} catch(Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>