<?php
require 'config/db.php';

// Fetch complaints without resolution_note and date_resolved
$query = "SELECT complaint_id, status, assigned_to FROM complaints";
$stmt = $pdo->prepare($query);
$stmt->execute();
$complaints = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Generate CSV
header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="complaints_report.csv"');
$output = fopen('php://output', 'w');

// Add headers
fputcsv($output, ['Complaint ID', 'Status', 'Assigned To']);

// Add rows
foreach ($complaints as $complaint) {
    $assignedTo = $complaint['assigned_to'] ? $complaint['assigned_to'] : 'Unassigned';
    fputcsv($output, [
        'CTRT-' . str_pad($complaint['complaint_id'], 6, '0', STR_PAD_LEFT),
        $complaint['status'],
        $assignedTo
    ]);
}

fclose($output);
?>