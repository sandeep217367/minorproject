<?php
require_once 'config/db.php';

try {
    $stmt = $pdo->query('SHOW COLUMNS FROM complaints WHERE Field = "assigned_to"');
    $column = $stmt->fetch(PDO::FETCH_ASSOC);
    print_r($column);
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
