<?php
require __DIR__ . '/config/db.php';
header('Content-Type: text/plain');

try {
    echo "Current feedback table structure:\n";
    $hasFeedback = $pdo->query("SHOW TABLES LIKE 'feedback'")->fetchColumn();
    
    if ($hasFeedback) {
        $cols = $pdo->query("SHOW COLUMNS FROM feedback")->fetchAll(PDO::FETCH_ASSOC);
        foreach($cols as $c){
            echo "  - {$c['Field']} ({$c['Type']})\n";
        }
        
        // Drop existing table to recreate with proper structure
        $pdo->exec("DROP TABLE feedback");
        echo "\nDropped existing feedback table\n";
    }
    
    // Create feedback table with proper structure
    $pdo->exec("CREATE TABLE feedback (
        feedback_id INT AUTO_INCREMENT PRIMARY KEY,
        complaint_id INT NOT NULL,
        user_id INT DEFAULT NULL,
        rating TINYINT NOT NULL CHECK (rating >= 1 AND rating <= 5),
        comments TEXT,
        date_given TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (complaint_id) REFERENCES complaints(complaint_id) ON DELETE CASCADE,
        FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL
    )");
    
    echo "\nCreated feedback table with proper structure.\n";
    
    // Show final structure
    echo "\nFinal feedback table structure:\n";
    $cols = $pdo->query("SHOW COLUMNS FROM feedback")->fetchAll(PDO::FETCH_ASSOC);
    foreach($cols as $c){
        echo "  - {$c['Field']} ({$c['Type']})" . 
             ($c['Key'] ? " [{$c['Key']}]" : "") . 
             ($c['Default'] ? " default: {$c['Default']}" : "") . "\n";
    }

    echo "\nFeedback table fixed successfully.\n";
} catch(Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>