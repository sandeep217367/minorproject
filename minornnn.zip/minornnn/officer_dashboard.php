<?php
require 'config/db.php';
session_start();
if(empty($_SESSION['officer_id'])){ header('Location: officer_login.php'); exit; }
$officer_id = $_SESSION['officer_id'];

// Ensure complaints has assigned_to column; be defensive to avoid PDOExceptions
$hasAssigned = (bool)$pdo->query("SHOW COLUMNS FROM complaints LIKE 'assigned_to'")->fetchColumn();
if(!$hasAssigned){
  // try to add the column (best-effort)
  try{ $pdo->exec("ALTER TABLE complaints ADD COLUMN assigned_to INT DEFAULT NULL"); $hasAssigned = true; } catch(Exception $e){ /* ignore */ }
}

if($hasAssigned){
  // Fetch complaints assigned to this officer
  $sql = "SELECT c.*, u.name as user_name, u.email as user_email FROM complaints c LEFT JOIN users u ON u.user_id = c.user_id WHERE c.assigned_to = ? ORDER BY c.created_at DESC";
  $stmt = $pdo->prepare($sql); $stmt->execute([$officer_id]); $rows = $stmt->fetchAll();
} else {
  // fallback: no assigned_to column available; show empty list and an admin hint
  $rows = [];
}

?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Officer Dashboard</title>
  <link rel="stylesheet" href="assets/style.css">
  <script src="assets/app.js" defer></script>
</head>
<body>
<?php include __DIR__ . '/inc/header.php'; ?>
<main class="dashboard-wrap">
  <section class="user-hero" style="display:flex;gap:1rem;align-items:center">
    <img src="assets/images/avatar-placeholder.svg" alt="avatar" style="width:84px;height:84px;border-radius:12px">
    <div>
      <h1 style="margin:.1rem 0">Hello, <?=esc($_SESSION['officer_name'] ?? 'Officer')?></h1>
      <p class="muted">Manage complaints assigned to you — review, update status, and add remarks.</p>
    </div>
    <div style="margin-left:auto;display:flex;gap:.5rem;align-items:center">
      <a class="btn" href="export_csv.php?for=officer&officer_id=<?=$officer_id?>">Export CSV</a>
    </div>
  </section>

  <section class="kpis" style="display:grid;grid-template-columns:repeat(4,1fr);gap:1rem;margin-top:1rem">
    <?php
      // compute officer KPI counts
      $totStmt = $pdo->prepare('SELECT COUNT(*) FROM complaints WHERE assigned_to=?'); $totStmt->execute([$officer_id]); $totalComplaints = (int)$totStmt->fetchColumn();
      $pendingStmt = $pdo->prepare("SELECT COUNT(*) FROM complaints WHERE assigned_to=? AND status='Pending'"); $pendingStmt->execute([$officer_id]); $pending = (int)$pendingStmt->fetchColumn();
      $inprogStmt = $pdo->prepare("SELECT COUNT(*) FROM complaints WHERE assigned_to=? AND status='In Progress'"); $inprogStmt->execute([$officer_id]); $inprogress = (int)$inprogStmt->fetchColumn();
      $resolvedStmt = $pdo->prepare("SELECT COUNT(*) FROM complaints WHERE assigned_to=? AND status='Resolved'"); $resolvedStmt->execute([$officer_id]); $resolved = (int)$resolvedStmt->fetchColumn();
    ?>
    <div class="feature-card"><strong style="font-size:1.4rem"><?=$totalComplaints?></strong><div class="muted">Assigned</div></div>
    <div class="feature-card"><strong style="font-size:1.4rem;color:#ef4444"><?=$pending?></strong><div class="muted">Pending</div></div>
    <div class="feature-card"><strong style="font-size:1.4rem;color:#f59e0b"><?=$inprogress?></strong><div class="muted">In Progress</div></div>
    <div class="feature-card"><strong style="font-size:1.4rem;color:#10b981"><?=$resolved?></strong><div class="muted">Resolved</div></div>
  </section>

  <section class="controls" style="display:flex;gap:1rem;align-items:center;margin:1rem 0">
    <div class="filters" role="tablist">
      <button class="filter-btn" data-status="">All</button>
      <button class="filter-btn" data-status="Pending">Pending</button>
      <button class="filter-btn" data-status="In Progress">In Progress</button>
      <button class="filter-btn" data-status="Resolved">Resolved</button>
    </div>
    <div class="search" style="margin-left:auto;display:flex;gap:.5rem;align-items:center">
      <input id="searchInput" placeholder="Search complaints..." type="search">
    </div>
  </section>

  <section id="complaintsList">
    <?php if(empty($rows)): ?>
      <div class="card-complaint"><p class="muted">No complaints assigned to you yet.</p></div>
    <?php else: ?>
      <div class="complaint-grid" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:1rem">
      <?php foreach($rows as $r): ?>
        <?php $desc = esc($r['description']); $status = esc($r['status']); $cid = esc($r['complaint_id']); ?>
        <article class="card-complaint" data-status="<?= $status ?>" data-desc="<?= htmlspecialchars($r['description']) ?>">
          <div style="display:flex;gap:.8rem">
            <img src="assets/images/complaint-thumb.svg" alt="thumb" style="width:120px;height:72px;border-radius:8px;object-fit:cover">
            <div style="flex:1">
              <h4 style="margin:0"><?=esc($r['category']?:'Untitled')?></h4>
              <div class="meta">Tracking ID: <strong>CTRT-<?=str_pad($r['complaint_id'],6,'0',STR_PAD_LEFT)?></strong> &nbsp;|&nbsp; Filed: <?=esc($r['created_at'] ?: $r['date_submitted'])?> | Status: <strong><?= $status ?></strong></div>
              <p style="margin:.4rem 0;max-height:3.6rem;overflow:hidden"><?=nl2br($desc)?></p>
              <div style="display:flex;gap:.5rem;align-items:center">
                <select class="status-select">
                  <option value="">-- Set status --</option>
                  <option value="Pending">Pending</option>
                  <option value="In Progress">In Progress</option>
                  <option value="Resolved">Resolved</option>
                </select>
                <button class="btn btn-update small" data-cid="<?= $cid ?>">Update</button>
                <button class="btn small view-btn" type="button" data-info='<?=htmlspecialchars(json_encode(['complaint_id'=>$r['complaint_id'],'category'=>$r['category']??'Untitled','created_at'=>$r['created_at']??($r['date_submitted']??''),'status'=>$r['status']??'','description'=>$r['description']??($r['remarks']??''),'evidence_file'=>$r['evidence_file']??($r['evidence']??''),'user_name'=>$r['user_name']??'','user_email'=>$r['user_email']??'']), ENT_QUOTES)?>'>View</button>
              </div>
              <div style="margin-top:.5rem"><textarea class="remark-input" placeholder="Add remarks (optional)" rows="2"></textarea></div>
            </div>
          </div>
        </article>
      <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </section>

  <!-- Complaint details modal -->
  <div id="complaintModal" class="modal-backdrop hidden" role="dialog" aria-hidden="true">
    <div class="modal" role="document">
      <button id="closeModal" style="float:right">Close</button>
      <h3 id="m_category">Category</h3>
      <p><strong>Tracking ID:</strong> <span id="m_tid"></span></p>
      <p><strong>Filed by:</strong> <span id="m_user"></span> | <strong>Filed:</strong> <span id="m_filed"></span></p>
      <p><strong>Status:</strong> <span id="m_status"></span></p>
      <div id="m_progress"></div>
  <p><strong>Description:</strong><br><div id="m_desc"></div></p>
  <p id="m_attach" style="display:none"><strong>Attachment:</strong> <a id="m_attach_link" target="_blank">View</a></p>
  <p id="m_resolution_wrap" style="display:none"><strong>Resolution note:</strong><br><div id="m_resolution"></div></p>
    </div>
  </div>

</main>
<?php include __DIR__ . '/inc/footer.php'; ?>
<script>
(() => {
  // update action (cards)
  document.addEventListener('click', async (ev) => {
    const btn = ev.target.closest('.btn-update');
    if(!btn) return;
    const cid = btn.getAttribute('data-cid');
    const card = btn.closest('.card-complaint');
    const sel = card.querySelector('.status-select');
    const status = sel?sel.value:'';
    const remarks = card.querySelector('.remark-input')?.value||'';
    if(!status){ alert('Please select a status'); return; }
    btn.disabled = true;
    try{
      const res = await fetch('officer_actions.php', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({action:'update_status', complaint_id:cid, status:status, remarks:remarks})});
      const j = await res.json();
      if(j.ok){
        // reflect status on the card
        card.querySelector('.meta strong') && (card.querySelector('.meta strong').textContent = status);
        sel.value=''; card.querySelector('.remark-input').value='';
      } else alert(j.message || 'Update failed');
    }catch(e){ console.error(e); alert('Network error'); }
    btn.disabled = false;
  });

  // filtering and search
  document.querySelectorAll('.filter-btn').forEach(b=> b.addEventListener('click', ()=>{
    const status = b.getAttribute('data-status');
    document.querySelectorAll('.card-complaint').forEach(c=>{ if(!status || c.getAttribute('data-status')===status) c.style.display=''; else c.style.display='none'; });
  }));
  document.getElementById('searchInput')?.addEventListener('input', (e)=>{
    const q = (e.target.value||'').toLowerCase();
    document.querySelectorAll('.card-complaint').forEach(c=>{ const t = c.textContent.toLowerCase(); c.style.display = (!q || t.indexOf(q)!==-1)?'':'none'; });
  });

  // view details modal
  document.addEventListener('click', async (ev)=>{
    const v = ev.target.closest('.view-btn'); if(!v) return;
    try{
      const info = JSON.parse(v.getAttribute('data-info'));
      const res = await fetch('track.php?q=' + encodeURIComponent('CTRT-' + String(info.complaint_id).padStart(6,'0')));
      const j = await res.json();
      let d = j.ok ? (Array.isArray(j.data)? j.data[0] : j.data) : info;
      document.getElementById('m_category').textContent = d.category || info.category || 'Untitled';
      document.getElementById('m_tid').textContent = 'CTRT-' + String(info.complaint_id).padStart(6,'0');
      document.getElementById('m_user').textContent = d.user_name || info.user_name || '';
      if(d.user_email) document.getElementById('m_user').textContent += ' ('+d.user_email+')';
      document.getElementById('m_filed').textContent = d.created_at || d.date_submitted || info.created_at || '';
      document.getElementById('m_status').textContent = d.status || info.status || '';
      document.getElementById('m_desc').innerHTML = (d.description||d.remarks||info.description||'').replace(/\n/g,'<br>');
      const att = d.evidence_file || d.evidence || info.evidence_file || '';
      const mAttach = document.getElementById('m_attach'); const mLink = document.getElementById('m_attach_link');
  if(att && mAttach && mLink){ mAttach.style.display='block'; mLink.href = att; } else if(mAttach) mAttach.style.display='none';
  // resolution note
  const resWrap = document.getElementById('m_resolution_wrap'); const resEl = document.getElementById('m_resolution');
  if(resEl && typeof d.resolution_note !== 'undefined' && d.resolution_note){ resEl.textContent = d.resolution_note; if(resWrap) resWrap.style.display='block'; } else if(resWrap) resWrap.style.display='none';
      const modal = document.getElementById('complaintModal'); if(modal){ modal.classList.remove('hidden'); modal.classList.add('show'); modal.setAttribute('aria-hidden','false'); }
      if(typeof renderProgress === 'function') renderProgress(document.getElementById('m_progress'), d.status||info.status||'');
    }catch(e){ console.error(e); alert('Could not load details'); }
  });

  // close modal
  document.getElementById('closeModal')?.addEventListener('click', ()=>{ const m=document.getElementById('complaintModal'); if(m){ m.classList.remove('show'); m.classList.add('hidden'); m.setAttribute('aria-hidden','true'); } });
  document.addEventListener('keydown', (ev)=>{ if(ev.key === 'Escape'){ const m=document.getElementById('complaintModal'); if(m && m.classList.contains('show')){ m.classList.remove('show'); m.classList.add('hidden'); m.setAttribute('aria-hidden','true'); } } });

})();
</script>
</body>
</html>
