<?php
session_start();
// Clear admin session and redirect to admin login
unset($_SESSION['admin_id']);
unset($_SESSION['admin_name']);
session_destroy();
header('Location: index.php'); exit;
