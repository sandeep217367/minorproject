<?php
session_start();
unset($_SESSION['user_id']);
unset($_SESSION['name']);
// Do not destroy admin session if present
header('Location: index.php'); exit;
