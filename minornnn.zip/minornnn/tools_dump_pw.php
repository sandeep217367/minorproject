<?php
require __DIR__ . '/config/db.php';

try{
    echo "ADMINS:\n";
    $admins = $pdo->query('SELECT admin_id,email,password FROM admins LIMIT 10')->fetchAll();
    print_r($admins);
    echo "\nOFFICERS:\n";
    $off = $pdo->query('SELECT officer_id,email,password_hash FROM officers LIMIT 10')->fetchAll();
    print_r($off);
} catch (Exception $e){
    echo "Error: " . $e->getMessage();
}

?>