<?php
require_once 'config/db.php';

try {
    $pdo->exec("INSERT INTO officers (name, department, contact, email, phone, password_hash) VALUES ('Default Officer', 'General', 'N/A', 'default@officer.com', '0000000000', 'default_hash')");
    echo "Default officer added successfully.";
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
