<?php
require_once __DIR__ . '/config/db.php';

$table = 'complaints';
$col = 'category';
$exists = false;
$res = $pdo->query("SHOW COLUMNS FROM $table");
foreach ($res as $row) {
    if ($row['Field'] === $col) {
        $exists = true;
        break;
    }
}
if (!$exists) {
    $pdo->exec("ALTER TABLE $table ADD COLUMN $col VARCHAR(191) DEFAULT NULL");
    echo "Column 'category' added to complaints table.<br>";
} else {
    echo "Column 'category' already exists in complaints table.<br>";
}
?>