-- Migration script to adapt existing DB to the app schema expected by the PHP app.
-- BACKUP your database before running this script.

-- 1) Create 'admins' table app expects, then copy existing admin(s) into it
CREATE TABLE IF NOT EXISTS admins (
  admin_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150),
  email VARCHAR(150) UNIQUE,
  password VARCHAR(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO admins (name, email, password)
SELECT username, CONCAT(username,'@example.com'), password
FROM admin
ON DUPLICATE KEY UPDATE name=VALUES(name);

-- 2) Add columns to 'complaints' table that the app expects (non-destructive)
ALTER TABLE complaints
  ADD COLUMN IF NOT EXISTS title VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS department VARCHAR(100) NULL,
  ADD COLUMN IF NOT EXISTS file_path VARCHAR(255) NULL,
  ADD COLUMN IF NOT EXISTS assigned_to INT DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS resolution_note TEXT NULL,
  ADD COLUMN IF NOT EXISTS date_submitted DATETIME NULL,
  ADD COLUMN IF NOT EXISTS date_resolved DATETIME NULL,
  ADD COLUMN IF NOT EXISTS category VARCHAR(191) DEFAULT NULL;

-- 3) Migrate existing data into the new columns (non-destructive copy)
UPDATE complaints SET department = category WHERE (department IS NULL OR department = '') AND (category IS NOT NULL);
UPDATE complaints SET file_path = evidence_file WHERE (file_path IS NULL OR file_path = '') AND (evidence_file IS NOT NULL);
UPDATE complaints SET resolution_note = remarks WHERE (resolution_note IS NULL OR resolution_note = '') AND (remarks IS NOT NULL);
UPDATE complaints SET date_submitted = created_at WHERE date_submitted IS NULL AND created_at IS NOT NULL;
UPDATE complaints SET date_resolved = updated_at WHERE (LOWER(status) = 'resolved' OR status = 'Resolved') AND (date_resolved IS NULL OR date_resolved = '0000-00-00 00:00:00') AND updated_at IS NOT NULL;

-- 4) Add phone column to users, and copy mobile -> phone
ALTER TABLE users
  ADD COLUMN IF NOT EXISTS phone VARCHAR(30) NULL;

UPDATE users SET phone = mobile WHERE (phone IS NULL OR phone = '') AND mobile IS NOT NULL;

-- 5) Create officers table (empty) the app expects
CREATE TABLE IF NOT EXISTS officers (
  officer_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  department VARCHAR(100),
  contact VARCHAR(100)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 6) Create feedback table the app expects
CREATE TABLE IF NOT EXISTS feedback (
  feedback_id INT AUTO_INCREMENT PRIMARY KEY,
  complaint_id INT NOT NULL,
  rating TINYINT NOT NULL,
  comments TEXT,
  date_given DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (complaint_id) REFERENCES complaints(complaint_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Note: If your MySQL version doesn't support `ADD COLUMN IF NOT EXISTS`, run the ALTER statements
-- without the IF NOT EXISTS clause or run the script in a client that supports it.
