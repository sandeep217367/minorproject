-- SQL schema for complaint_tracker
CREATE DATABASE IF NOT EXISTS complaint_tracker CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE complaint_tracker;

CREATE TABLE IF NOT EXISTS users (
  user_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  phone VARCHAR(30),
  password VARCHAR(255) NOT NULL,
  date_created DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS admins (
  admin_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150),
  email VARCHAR(150) UNIQUE,
  password VARCHAR(255) NOT NULL
);

CREATE TABLE IF NOT EXISTS officers (
  officer_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  department VARCHAR(100),
  contact VARCHAR(100)
);

CREATE TABLE IF NOT EXISTS complaints (
  complaint_id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  department VARCHAR(100) NOT NULL,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  file_path VARCHAR(255),
  status VARCHAR(50) DEFAULT 'Pending',
  assigned_to INT DEFAULT NULL,
  resolution_note TEXT,
  date_submitted DATETIME DEFAULT CURRENT_TIMESTAMP,
  date_resolved DATETIME DEFAULT NULL,
  FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
  FOREIGN KEY (assigned_to) REFERENCES officers(officer_id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS feedback (
  feedback_id INT AUTO_INCREMENT PRIMARY KEY,
  complaint_id INT NOT NULL,
  rating TINYINT NOT NULL,
  comments TEXT,
  date_given DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (complaint_id) REFERENCES complaints(complaint_id) ON DELETE CASCADE
);

-- Seed a default admin
-- NOTE: Create an admin manually after importing or insert a hashed password via PHP.
-- Example (use PHP to create a hashed password with password_hash):
-- INSERT INTO admins (name, email, password) VALUES ('Administrator','admin@example.com','<hashed_password>');