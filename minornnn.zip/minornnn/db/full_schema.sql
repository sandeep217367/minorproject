-- USERS TABLE
CREATE TABLE IF NOT EXISTS users (
  user_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  phone VARCHAR(30),
  password VARCHAR(255) NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ADMINS TABLE
CREATE TABLE IF NOT EXISTS admins (
  admin_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL
);

-- OFFICERS TABLE
CREATE TABLE IF NOT EXISTS officers (
  officer_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  department VARCHAR(100),
  contact VARCHAR(100),
  email VARCHAR(191),
  phone VARCHAR(50),
  password_hash VARCHAR(255)
);

-- COMPLAINTS TABLE
CREATE TABLE IF NOT EXISTS complaints (
  complaint_id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  department VARCHAR(100),
  title VARCHAR(255),
  description TEXT,
  file_path VARCHAR(255),
  status VARCHAR(50),
  assigned_to INT,
  resolution_note TEXT,
  date_submitted DATETIME,
  date_resolved DATETIME,
  category VARCHAR(191),
  remarks TEXT,
  updated_at DATETIME,
  evidence_file VARCHAR(255)
);

-- FEEDBACK TABLE
CREATE TABLE IF NOT EXISTS feedback (
  feedback_id INT AUTO_INCREMENT PRIMARY KEY,
  complaint_id INT NOT NULL,
  rating TINYINT,
  comments TEXT,
  date_given DATETIME
);
