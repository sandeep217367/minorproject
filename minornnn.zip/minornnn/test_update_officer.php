<?php
require 'config/db.php';

try {
    $stmt = $pdo->prepare('UPDATE officers SET name=?, department=?, email=?, phone=? WHERE officer_id=?');
    $stmt->execute(['Updated Name', 'Updated Dept', 'updated@example.com', '1234567890', 1]);
    echo 'Update successful';
} catch (Exception $e) {
    echo 'Error: ' . $e->getMessage();
}