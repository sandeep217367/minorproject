<?php
require 'config/db.php';
session_start();
if(empty($_SESSION['user_id'])){ header('Location: login.php'); exit; }
$msg='';

// detect officers table and assigned_to column
$hasOfficers = (bool) $pdo->query("SHOW TABLES LIKE 'officers'")->fetchColumn();
$hasAssignedTo = (bool) $pdo->query("SHOW COLUMNS FROM complaints LIKE 'assigned_to'")->fetchColumn();

// fetch officers if available
$officers = [];
if($hasOfficers){
  $officers = $pdo->query('SELECT officer_id, name, department FROM officers ORDER BY name')->fetchAll();
}

// Dynamically fetch file upload settings
try {
    $stmt = $pdo->query("SELECT setting_key, setting_value FROM system_settings WHERE setting_key IN ('max_file_size', 'allowed_file_types')");
    $settings = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
    $max_file_size = isset($settings['max_file_size']) ? (int)$settings['max_file_size'] * 1024 * 1024 : 5 * 1024 * 1024; // Default to 5 MB
    $allowed_file_types = isset($settings['allowed_file_types']) ? explode(',', strtolower($settings['allowed_file_types'])) : ['pdf', 'jpg', 'jpeg', 'png', 'doc', 'docx'];
} catch (Exception $e) {
    // Fallback to defaults if database query fails
    $max_file_size = 5 * 1024 * 1024;
    $allowed_file_types = ['pdf', 'jpg', 'jpeg', 'png', 'doc', 'docx'];
}

if($_SERVER['REQUEST_METHOD']==='POST'){
  $user_id = $_SESSION['user_id'];
  $category = $_POST['department']??''; // map department -> category
  $description = $_POST['description']??'';
  $assigned_to = $hasAssignedTo ? (int)($_POST['assigned_to']??0) : null;
  $file_path = null;
  // Update validation logic for file upload
  if (!empty($_FILES['attachment']['name'])) {
    $up = $_FILES['attachment'];
    $ext = strtolower(pathinfo($up['name'], PATHINFO_EXTENSION));

    // Validate file size
    if ($up['size'] > $max_file_size) {
        $msg = 'File size exceeds the maximum limit of ' . ($max_file_size / 1024 / 1024) . ' MB.';
        $file_path = null; // Prevent file upload
    } elseif (!in_array($ext, $allowed_file_types)) {
        $msg = 'Invalid file type. Allowed types are: ' . implode(', ', $allowed_file_types) . '.';
        $file_path = null; // Prevent file upload
    } else {
        $dest = 'uploads/' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
        if (!is_dir('uploads')) mkdir('uploads', 0755, true);
        move_uploaded_file($up['tmp_name'], $dest);
        $file_path = $dest;
    }
  }
  if (empty($msg)) {
    // Validate assigned_to officer ID if applicable
    if ($hasAssignedTo && $assigned_to) {
      $stmt = $pdo->prepare('SELECT officer_id FROM officers WHERE officer_id = ?');
      $stmt->execute([$assigned_to]);
      if (!$stmt->fetchColumn()) {
        $assigned_to = null; // Set to NULL if invalid
      }
    }

    // Explicitly set assigned_to to NULL if not provided
    if (empty($assigned_to)) {
      $assigned_to = null;
    }

    // Insert using existing DB columns: include assigned_to only if column exists
    if($hasAssignedTo){
      $stmt = $pdo->prepare('INSERT INTO complaints (user_id,category,description,evidence_file,status,assigned_to,created_at) VALUES (?,?,?,?,?,?,NOW())');
      $stmt->execute([$user_id,$category,$description,$file_path,'Pending',$assigned_to]);
    } else {
      $stmt = $pdo->prepare('INSERT INTO complaints (user_id,category,description,evidence_file,status,created_at) VALUES (?,?,?,?,?,NOW())');
      $stmt->execute([$user_id,$category,$description,$file_path,'Pending']);
    }
    $id = $pdo->lastInsertId();
    $public_id = 'CTRT-'.str_pad($id,6,'0',STR_PAD_LEFT);
    $msg = 'Complaint filed. Your tracking ID: '. $public_id;
  }
}
// Prefill from quick-file query params if present
$prefill_cat = isset($_GET['category']) ? $_GET['category'] : '';
$prefill_desc = isset($_GET['desc']) ? $_GET['desc'] : '';
?>
<!doctype html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>File Complaint</title><link rel="stylesheet" href="assets/style.css"></head>
<body>
<?php include __DIR__ . '/inc/header.php'; ?>
<main class="dashboard-wrap">
  <div class="form">
    <h2>File Complaint</h2>
    <?php if($msg) echo '<p style="color:green">'.esc($msg).'</p>'; ?>
    <form method="post" enctype="multipart/form-data">
      <label>User</label><input value="<?=esc($_SESSION['name'])?>" disabled>
      <label>Department</label>
      <select name="department" required>
        <option <?= $prefill_cat==='Sanitation' ? 'selected' : '' ?>>Sanitation</option>
        <option <?= $prefill_cat==='Transport' ? 'selected' : '' ?>>Transport</option>
        <option <?= $prefill_cat==='Electricity' ? 'selected' : '' ?>>Electricity</option>
        <option <?= $prefill_cat==='Water' ? 'selected' : '' ?>>Water</option>
        <option <?= $prefill_cat==='Other' ? 'selected' : '' ?>>Other</option>
      </select>
  <label>Description</label><textarea name="description" rows="6"><?=esc(urldecode($prefill_desc))?></textarea>
      <?php if($hasOfficers && $hasAssignedTo): ?>
        <label>Assign Officer (optional)</label>
        <select name="assigned_to">
          <option value="0">-- Select officer --</option>
          <?php foreach($officers as $o): ?>
            <option value="<?=esc($o['officer_id'])?>"><?=esc($o['name'])?> (<?=esc($o['department'])?>)</option>
          <?php endforeach; ?>
        </select>
      <?php endif; ?>
      <label>Upload Image/Document (optional)</label>
      <div style="display:flex;gap:.6rem;align-items:center">
        <input type="file" name="attachment">
        <img src="assets/images/placeholder.svg" class="img-placeholder" alt="placeholder">
      </div>
      <div style="margin-top:.6rem"><button class="btn" type="submit">Submit</button></div>
    </form>
  </div>
</main>
<?php include __DIR__ . '/inc/footer.php'; ?>
<script>
// Handle file input change and preview image
const fileInput = document.querySelector('input[name="attachment"]');
const imgPlaceholder = document.querySelector('.img-placeholder');

fileInput.addEventListener('change', function () {
    const file = this.files[0];
    if (file) {
        const fileType = file.type;
        const validImageTypes = ['image/jpeg', 'image/png', 'image/jpg'];

        if (validImageTypes.includes(fileType)) {
            const reader = new FileReader();
            reader.onload = function (e) {
                imgPlaceholder.src = e.target.result;
            };
            reader.readAsDataURL(file);
        } else {
            imgPlaceholder.src = 'assets/images/placeholder.svg';
        }
    } else {
        imgPlaceholder.src = 'assets/images/placeholder.svg';
    }
});
</script>
</body></html>