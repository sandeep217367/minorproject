<?php
require 'config/db.php';
session_start();
if(empty($_SESSION['admin_id'])){ http_response_code(403); echo 'Forbidden'; exit; }

$hasOfficersTable = (bool)$pdo->query("SHOW TABLES LIKE 'officers'")->fetchColumn();
$hasAssignedCol = (bool)$pdo->query("SHOW COLUMNS FROM complaints LIKE 'assigned_to'")->fetchColumn();
$joinOfficers = $hasOfficersTable && $hasAssignedCol;
$selectExtra = $joinOfficers ? ', o.name as officer_name' : '';
$joinSql = $joinOfficers ? ' LEFT JOIN officers o ON c.assigned_to=o.officer_id' : '';
$complaints = $pdo->query('SELECT c.*, u.name as user_name' . $selectExtra . ' FROM complaints c LEFT JOIN users u ON c.user_id=u.user_id' . $joinSql . ' ORDER BY c.created_at DESC')->fetchAll();

foreach($complaints as $c){
  echo '<tr>';
  echo '<td>'.esc($c['complaint_id']).'</td>';
  echo '<td>'.esc($c['category'] ?? $c['category']).'</td>';
  echo '<td>'.esc($c['user_name'] ?? '').'</td>';
  echo '<td>'.nl2br(esc($c['description'] ?? $c['remarks'] ?? '')).'</td>';
  echo '<td>'.esc($c['status'] ?? '').'</td>';
  echo '<td>'.esc($c['officer_name'] ?? ($c['assigned_to'] ?? '')).'</td>';
  // actions column (reproduce same form markup compactly)
  echo '<td><form method="post" action="admin_actions.php" class="inline-form">';
  echo '<input type="hidden" name="id" value="'.esc($c['complaint_id']).'">';
  echo '<select name="status" class="small-select"><option>Pending</option><option>In Progress</option><option>Resolved</option></select>';
  if($hasOfficersTable){
    // build officer options
    $officers = $pdo->query('SELECT officer_id,name FROM officers ORDER BY name')->fetchAll();
    echo '<select name="assigned_to" class="small-select"><option value="">-- Unassigned --</option>';
    foreach($officers as $o){
      $sel = (isset($c['assigned_to']) && $c['assigned_to']==$o['officer_id'])? ' selected':'';
      echo '<option value="'.esc($o['officer_id']).'"'.$sel.'>'.esc($o['name']).'</option>';
    }
    echo '</select>';
  } else {
    echo '<input name="assigned_to" placeholder="Officer ID" class="small-input">';
  }
  echo '<input name="resolution_note" placeholder="Resolution note" class="small-input">';
  echo '<button class="btn small" type="submit">Update</button>';
  echo '</form></td>';
  echo '</tr>';
}
