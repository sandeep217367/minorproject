<?php
// Lightweight script to create an admin with hashed password.
require 'config/db.php';
if(PHP_SAPI !== 'cli'){
  echo "Run this script from CLI to create an admin.\n"; exit;
}
$name = $argv[1] ?? 'Administrator';
$email = $argv[2] ?? 'admin@example.com';
$password = $argv[3] ?? 'password123';
$hash = password_hash($password, PASSWORD_DEFAULT);
$stmt = $pdo->prepare('INSERT INTO admins (name,email,password) VALUES (?,?,?)');
try{ $stmt->execute([$name,$email,$hash]); echo "Admin created: $email\n"; }
catch(Exception $e){ echo "Error: ".$e->getMessage()."\n"; }
