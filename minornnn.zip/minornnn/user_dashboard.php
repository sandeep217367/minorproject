<?php
require 'config/db.php';
session_start();
if(empty($_SESSION['user_id'])){ header('Location: login.php'); exit; }
$user_id = $_SESSION['user_id'];
$qStatus = $_GET['status']??'';

// fetch complaints for the dashboard list (filtered if a status query provided)
$sql = 'SELECT * FROM complaints WHERE user_id=?';
$params = [$user_id];
if($qStatus){ $sql .= ' AND status=?'; $params[]=$qStatus; }
$hasCreated = (bool)$pdo->query("SHOW COLUMNS FROM complaints LIKE 'created_at'")->fetchColumn();
$hasDateSubmitted = (bool)$pdo->query("SHOW COLUMNS FROM complaints LIKE 'date_submitted'")->fetchColumn();
$hasUpdated = (bool)$pdo->query("SHOW COLUMNS FROM complaints LIKE 'updated_at'")->fetchColumn();
$orderCol = $hasCreated ? 'created_at' : ($hasDateSubmitted ? 'date_submitted' : ($hasUpdated ? 'updated_at' : 'complaint_id'));
$sql .= ' ORDER BY ' . $orderCol . ' DESC';
$stmt = $pdo->prepare($sql); $stmt->execute($params); $rows = $stmt->fetchAll();

// compute user KPI counts (ignore qStatus so user sees totals)
$totStmt = $pdo->prepare('SELECT COUNT(*) as c FROM complaints WHERE user_id=?'); $totStmt->execute([$user_id]); $totalComplaints = (int)$totStmt->fetchColumn();
$pendingStmt = $pdo->prepare("SELECT COUNT(*) FROM complaints WHERE user_id=? AND status='Pending'"); $pendingStmt->execute([$user_id]); $pending = (int)$pendingStmt->fetchColumn();
$inprogStmt = $pdo->prepare("SELECT COUNT(*) FROM complaints WHERE user_id=? AND status='In Progress'"); $inprogStmt->execute([$user_id]); $inprogress = (int)$inprogStmt->fetchColumn();
$resolvedStmt = $pdo->prepare("SELECT COUNT(*) FROM complaints WHERE user_id=? AND status='Resolved'"); $resolvedStmt->execute([$user_id]); $resolved = (int)$resolvedStmt->fetchColumn();
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Your Dashboard</title>
  <link rel="stylesheet" href="assets/style.css">
</head>
<body>

  <?php include __DIR__ . '/inc/header.php'; ?>

  <main class="dashboard-wrap">
    

    <section class="user-hero" style="display:flex;gap:1rem;align-items:center">
      <img src="assets/images/avatar-placeholder.svg" alt="avatar" style="width:84px;height:84px;border-radius:12px">
      <div>
        <h1 style="margin:.1rem 0">Hello, <?=esc($_SESSION['name'])?></h1>
        <p class="muted">Overview of your complaints and progress</p>
        <div style="margin-top:.6rem;display:flex;gap:.5rem">
          <a class="btn" href="file_complaint.php">File new</a>
          <a class="btn" href="export_csv.php">Export CSV</a>
        </div>
      </div>
    </section>

    <section class="kpis" style="display:grid;grid-template-columns:repeat(4,1fr);gap:1rem;margin-top:1rem">
      <div class="feature-card"><strong style="font-size:1.4rem"><?= $totalComplaints ?></strong><div class="muted">Total filed</div></div>
      <div class="feature-card"><strong style="font-size:1.4rem;color:#ef4444"><?= $pending ?></strong><div class="muted">Pending</div></div>
      <div class="feature-card"><strong style="font-size:1.4rem;color:#f59e0b"><?= $inprogress ?></strong><div class="muted">In Progress</div></div>
      <div class="feature-card"><strong style="font-size:1.4rem;color:#10b981"><?= $resolved ?></strong><div class="muted">Resolved</div></div>
    </section>

    <section class="controls" style="display:flex;gap:1rem;align-items:center;margin:1rem 0">
      <div class="filters" role="tablist">
        <button class="filter-btn" data-status="">All</button>
        <button class="filter-btn" data-status="Pending">Pending</button>
        <button class="filter-btn" data-status="In Progress">In Progress</button>
        <button class="filter-btn" data-status="Resolved">Resolved</button>
      </div>

      <div class="search" style="margin-left:auto;display:flex;gap:.5rem;align-items:center">
        <input id="searchInput" placeholder="Search complaints..." type="search">
        <a class="btn" href="file_complaint.php">File new</a>
        <a class="btn" href="export_csv.php">Export CSV</a>
      </div>
    </section>

    <section id="complaintsList">
      <?php if(empty($rows)): ?>
        <div class="card-complaint">
          <p class="muted">You haven't filed any complaints yet. <a href="file_complaint.php">File one now</a>.</p>
        </div>
      <?php else: ?>
        <div class="complaint-grid" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:1rem">
        <?php foreach($rows as $r): ?>
          <?php $desc = esc($r['description']); $status = esc($r['status']); $cid = esc($r['complaint_id']); ?>
          <article class="card-complaint" data-status="<?= $status ?>" data-description="<?= htmlspecialchars($r['description']) ?>">
            <div style="display:flex;gap:.8rem">
              <img src="assets/images/complaint-thumb.svg" alt="thumb" style="width:120px;height:72px;border-radius:8px;object-fit:cover">
              <div style="flex:1">
                <h4 style="margin:0"><?=esc($r['category']?:'Untitled')?></h4>
                <div class="meta">Tracking ID: <strong>CTRT-<?=str_pad($r['complaint_id'],6,'0',STR_PAD_LEFT)?></strong> &nbsp;|&nbsp; Filed: <?=esc($r['created_at'] ?: $r['date_submitted'])?> | Status: <strong><?= $status ?></strong></div>
                <p style="margin:.4rem 0;max-height:3.6rem;overflow:hidden"><?=nl2br($desc)?></p>
                <div style="display:flex;gap:.5rem;align-items:center">
                  <?php
                    $info = [
                      'complaint_id'=>$r['complaint_id'],
                      'category'=>$r['category']??'Untitled',
                      'created_at'=>$r['created_at']??($r['date_submitted']??''),
                      'status'=>$r['status']??'',
                      'description'=>$r['description']??($r['remarks']??''),
                      'evidence_file'=>$r['evidence_file']??($r['evidence']??''),
                      'assigned_to'=>$r['assigned_to']??null,
                      'user_name'=>$_SESSION['name'] ?? ''
                    ];
                  ?>
                  <button class="btn view-btn" type="button" data-info='<?=htmlspecialchars(json_encode($info), ENT_QUOTES)?>'>View</button>
                  <?php if($r['status']=='Pending'): ?>
                    <form method="post" action="delete_complaint.php" style="display:inline">
                      <input type="hidden" name="id" value="<?= $cid ?>">
                      <button class="btn" type="submit" style="background:#ef4444">Delete</button>
                    </form>
                  <?php endif; ?>
                </div>
              </div>
            </div>
          </article>
        <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </section>
    
      <!-- Complaint details modal -->
      <div id="complaintModal" class="modal-backdrop hidden" role="dialog" aria-hidden="true">
        <div class="modal" role="document">
          <button id="closeModal" style="float:right">Close</button>
          <h3 id="m_category">Category</h3>
          <p><strong>Tracking ID:</strong> <span id="m_tid"></span></p>
          <p><strong>Filed by:</strong> <span id="m_user"></span> | <strong>Filed:</strong> <span id="m_filed"></span></p>
          <p><strong>Status:</strong> <span id="m_status"></span></p>
          <div id="m_progress"></div>
          <p><strong>Description:</strong><br><div id="m_desc"></div></p>
          <p id="m_attach" style="display:none"><strong>Attachment:</strong> <a id="m_attach_link" target="_blank">View</a></p>
        </div>
      </div>
  </main>

<script>
document.addEventListener('DOMContentLoaded', function(){
  const modal = document.getElementById('complaintModal');
  const closeBtn = document.getElementById('closeModal');
  if(!modal) return;

  function openModal(info){
    document.getElementById('m_category').textContent = info.category || 'Untitled';
    document.getElementById('m_tid').textContent = 'CTRT-' + String(info.complaint_id).padStart(6,'0');
    document.getElementById('m_user').textContent = info.user_name || '';
    document.getElementById('m_filed').textContent = info.created_at || '';
    document.getElementById('m_status').textContent = info.status || '';
    // set description (allow basic newlines)
    const descEl = document.getElementById('m_desc');
    descEl.innerHTML = info.description ? ('<div>' + String(info.description).replace(/\n/g,'<br>') + '</div>') : '';

    const attachEl = document.getElementById('m_attach');
    // Normalize attachment path and show image preview for images
    if (info.evidence_file && info.evidence_file !== '') {
      let href = String(info.evidence_file).trim();

      // Remove leading ./ or / characters
      href = href.replace(/^(?:\.\/|\/+)+/, '');

      // If href is not an absolute URL (http(s) or starting with /), ensure a single uploads/ prefix
      if (!href.match(/^(https?:)?\/\//i) && !href.match(/^\//)) {
        // remove any repeated uploads/ prefixes
        href = href.replace(/^(?:uploads\/)+/i, '');
        href = 'uploads/' + href;
      }

      // detect extension
      const mExt = href.match(/\.([a-z0-9]+)(?:[\?#]|$)/i);
      const ext = mExt ? mExt[1].toLowerCase() : '';
      const imageTypes = ['jpg','jpeg','png','gif','webp','bmp'];

      if (imageTypes.includes(ext)) {
        attachEl.style.display = 'block';
        // show inline image preview
        attachEl.innerHTML = '<strong>Attachment:</strong><br><img id="m_attach_img" src="' + href + '" alt="attachment" style="max-width:100%;max-height:360px;border-radius:6px;margin-top:.5rem">';
      } else {
        attachEl.style.display = 'block';
        attachEl.innerHTML = '<strong>Attachment:</strong> <a id="m_attach_link" href="' + href + '" target="_blank">View</a>';
      }
    } else {
      attachEl.style.display = 'none';
      attachEl.innerHTML = '<strong>Attachment:</strong> <a id="m_attach_link" target="_blank"></a>';
    }

    // show modal
    modal.classList.remove('hidden');
    modal.classList.add('show');
    modal.setAttribute('aria-hidden','false');
  }

  function closeModal(){
    modal.classList.remove('show');
    modal.classList.add('hidden');
    modal.setAttribute('aria-hidden','true');
  }

  closeBtn && closeBtn.addEventListener('click', closeModal);
  // close when clicking backdrop
  modal.addEventListener('click', function(e){ if(e.target === modal) closeModal(); });

  // wire view buttons
  document.querySelectorAll('.view-btn').forEach(function(btn){
    btn.addEventListener('click', function(){
      const raw = btn.getAttribute('data-info') || '{}';
      try{
        const info = JSON.parse(raw);
        openModal(info);
      }catch(err){
        console.error('Failed to parse complaint info', err, raw);
        alert('Unable to open complaint details');
      }
    });
  });
});
</script>

<?php include __DIR__ . '/inc/footer.php'; ?>

</body>
</html>
