<?php
require __DIR__ . '/config/db.php';
header('Content-Type: text/plain');

try {
    echo "Current officers table structure:\n";
    $cols = $pdo->query("SHOW COLUMNS FROM officers")->fetchAll(PDO::FETCH_ASSOC);
    foreach($cols as $c){
        echo "  - {$c['Field']} ({$c['Type']})\n";
    }

    // Drop and recreate officers table with correct structure
    $pdo->exec("DROP TABLE IF EXISTS officers");
    
    $pdo->exec("CREATE TABLE officers (
        officer_id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(191) NOT NULL,
        department VARCHAR(191) DEFAULT NULL,
        email VARCHAR(191) UNIQUE,
        phone VARCHAR(50) DEFAULT NULL,
        password_hash VARCHAR(255) DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");
    
    echo "\nRecreated officers table with correct structure.\n";
    
    // Show final structure
    echo "\nFinal officers table structure:\n";
    $cols = $pdo->query("SHOW COLUMNS FROM officers")->fetchAll(PDO::FETCH_ASSOC);
    foreach($cols as $c){
        echo "  - {$c['Field']} ({$c['Type']})" . 
             ($c['Key'] ? " [{$c['Key']}]" : "") . 
             ($c['Default'] ? " default: {$c['Default']}" : "") . "\n";
    }

    // Create a test officer if none exists
    $count = $pdo->query("SELECT COUNT(*) FROM officers")->fetchColumn();
    if ($count == 0) {
        $hash = password_hash('officer123', PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO officers (name, department, email, phone, password_hash) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute(['Test Officer', 'General', 'officer@example.com', '1234567890', $hash]);
        echo "\nCreated test officer:\n";
        echo "Email: officer@example.com\n";
        echo "Password: officer123\n";
    }

    echo "\nOfficers table fixed successfully.\n";
} catch(Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}

$existing = $pdo->query("SHOW COLUMNS FROM $table")->fetchAll(PDO::FETCH_COLUMN, 0);
$added = [];
foreach ($columns as $col => $def) {
    if (!in_array($col, $existing)) {
        $pdo->exec("ALTER TABLE $table ADD COLUMN $col $def");
        $added[] = $col;
    }
}

if ($added) {
    echo "Added missing columns: " . implode(', ', $added) . "<br>";
} else {
    echo "All required columns already exist.<br>";
}

// Show final schema
$res = $pdo->query("SHOW COLUMNS FROM $table");
echo '<h3>complaints table columns:</h3><ul>';
foreach ($res as $row) {
    echo '<li>' . htmlspecialchars($row['Field']) . ' - ' . htmlspecialchars($row['Type']) . '</li>';
}
echo '</ul>';
?>