<?php
require 'config/db.php';
session_start();
if(empty($_SESSION['user_id'])){ header('Location: login.php'); exit; }
if($_SERVER['REQUEST_METHOD']==='POST'){
  $id = (int)($_POST['id']??0);
  $stmt = $pdo->prepare('SELECT * FROM complaints WHERE complaint_id=? AND user_id=?');
  $stmt->execute([$id, $_SESSION['user_id']]);
  $c = $stmt->fetch();
  if($c && $c['status']=='Pending'){
    $pdo->prepare('DELETE FROM complaints WHERE complaint_id=?')->execute([$id]);
  }
}
header('Location: user_dashboard.php'); exit;
