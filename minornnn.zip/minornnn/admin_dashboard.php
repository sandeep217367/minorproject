<?php
require 'config/db.php';
session_start();
if(empty($_SESSION['admin_id'])){ header('Location: admin_login.php'); exit; }
// Fetch stats
$tot = $pdo->query('SELECT COUNT(*) as c FROM complaints')->fetchColumn();
$res = $pdo->query("SELECT status, COUNT(*) as c FROM complaints GROUP BY status")->fetchAll();
$byDept = $pdo->query("SELECT category, COUNT(*) as c FROM complaints GROUP BY category")->fetchAll();
// Detect officers table and assigned_to column before joining
$hasOfficersTable = (bool)$pdo->query("SHOW TABLES LIKE 'officers'")->fetchColumn();
$hasAssignedCol = (bool)$pdo->query("SHOW COLUMNS FROM complaints LIKE 'assigned_to'")->fetchColumn();
$joinOfficers = $hasOfficersTable && $hasAssignedCol;
$selectExtra = $joinOfficers ? ', o.name as officer_name' : '';
$joinSql = $joinOfficers ? ' LEFT JOIN officers o ON c.assigned_to=o.officer_id' : '';
$complaints = $pdo->query('SELECT c.*, u.name as user_name' . $selectExtra . ' FROM complaints c LEFT JOIN users u ON c.user_id=u.user_id' . $joinSql . ' ORDER BY c.created_at DESC')->fetchAll();
// fetch officers for dropdown if table exists
$officerList = [];
if($hasOfficersTable){
  $officerList = $pdo->query('SELECT officer_id,name FROM officers ORDER BY name')->fetchAll();
}
?>
<!doctype html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Admin Dashboard</title><link rel="stylesheet" href="assets/style.css"><script src="https://cdn.jsdelivr.net/npm/chart.js"></script></head>
<body>
<?php include __DIR__ . '/inc/header.php'; ?>
<main class="dashboard-wrap">
  <div class="panel">
    <div class="panel-header"><h2>Admin Dashboard</h2><div class="panel-actions"><span class="muted">Welcome, <?=esc($_SESSION['admin_name'])?></span> <a href="export_csv.php" target="_blank" class="btn">Export CSV</a></div></div>

    <div class="kpi-row">
      <div class="kpi"><div class="kpi-title">Total Complaints</div><div class="kpi-value"><?=$tot?></div></div>
      <?php foreach($res as $r): ?>
        <div class="kpi"><div class="kpi-title"><?=esc($r['status'])?></div><div class="kpi-value"><?=esc($r['c'])?></div></div>
      <?php endforeach; ?>
    </div>

    <h3 style="margin-top:1.25rem">Complaints</h3>
    <div class="table-card">
      <table class="admin-table">
        <thead><tr><th>ID</th><th>Category</th><th>User</th><th>Description</th><th>Status</th><th>Officer</th><th>Actions</th></tr></thead>
        <tbody id="complaintsBody">
          <?php foreach($complaints as $c): ?>
            <tr>
              <td><?=esc($c['complaint_id'])?></td>
              <td><?=esc($c['category'] ?? $c['category'])?></td>
              <td><?=esc($c['user_name'] ?? '')?></td>
              <td><?=nl2br(esc($c['description'] ?? $c['remarks'] ?? ''))?></td>
              <td><?=esc($c['status'] ?? '')?></td>
              <td><?=esc($c['officer_name'] ?? ($c['assigned_to'] ?? ''))?></td>
              <td>
                <form method="post" action="admin_actions.php" class="inline-form">
                  <input type="hidden" name="id" value="<?=esc($c['complaint_id'])?>">
                  <select name="status" class="small-select"><option>Pending</option><option>In Progress</option><option>Resolved</option></select>
                  <?php if($hasOfficersTable): ?>
                    <select name="assigned_to" class="small-select">
                      <option value="">-- Unassigned --</option>
                      <?php foreach($officerList as $o): ?>
                        <option value="<?=esc($o['officer_id'])?>" <?=((isset($c['assigned_to']) && $c['assigned_to']==$o['officer_id'])?'selected':'')?>><?=esc($o['name'])?></option>
                      <?php endforeach; ?>
                    </select>
                  <?php else: ?>
                    <input name="assigned_to" placeholder="Officer ID" class="small-input">
                  <?php endif; ?>
                  <input name="resolution_note" placeholder="Resolution note" class="small-input">
                  <button class="btn small" type="submit">Update</button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</main>
<?php include __DIR__ . '/inc/footer.php'; ?>
<script>
// Poll the server for updated complaints table body so admin sees officer updates in near-real-time
async function refreshComplaints(){
  try{
    const res = await fetch('admin_refresh.php');
    if(!res.ok) return;
    const html = await res.text();
    const tbody = document.getElementById('complaintsBody');
    if(tbody) tbody.innerHTML = html;
  }catch(e){ console.error('refresh error', e); }
}
// refresh every 8 seconds
setInterval(refreshComplaints, 8000);
</script>
</body></html>
