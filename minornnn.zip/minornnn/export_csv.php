<?php
require 'config/db.php';
header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="complaints.csv"');

$output = fopen('php://output', 'w');
fputcsv($output, ['Complaint ID', 'Status', 'Assigned To', 'Resolution Note', 'Date Resolved']);

$stmt = $pdo->query('SELECT complaint_id, status, assigned_to, resolution_note, date_resolved FROM complaints');
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    // Format Complaint ID
    $row['complaint_id'] = 'CTRT' . str_pad($row['complaint_id'], 6, '0', STR_PAD_LEFT);

    // Fetch Assigned To Name
    $assignedToStmt = $pdo->prepare('SELECT name FROM officers WHERE officer_id = ?');
    $assignedToStmt->execute([$row['assigned_to']]);
    $assignedTo = $assignedToStmt->fetchColumn();
    $row['assigned_to'] = $assignedTo ? $assignedTo : 'Unassigned';

    // Ensure Resolution Note and Date Resolved are not empty
    $row['resolution_note'] = $row['resolution_note'] ?: 'No resolution note';
    $row['date_resolved'] = $row['date_resolved'] ?: 'Not resolved';

    fputcsv($output, $row);
}
fclose($output);
exit;
